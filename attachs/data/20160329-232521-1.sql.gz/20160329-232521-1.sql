-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : baocms
-- 
-- Part : #1
-- Date : 2016-03-29 23:25:21
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `bao_activity`
-- -----------------------------
DROP TABLE IF EXISTS `bao_activity`;
CREATE TABLE `bao_activity` (
  `activity_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` int(10) DEFAULT '0',
  `shop_id` int(10) DEFAULT NULL,
  `tuan_id` int(11) DEFAULT '0',
  `city_id` smallint(5) unsigned DEFAULT '0',
  `area_id` smallint(5) unsigned DEFAULT '0',
  `business_id` smallint(5) unsigned DEFAULT '0',
  `title` varchar(128) DEFAULT NULL,
  `intro` varchar(128) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `thumb` text,
  `details` text,
  `price` decimal(32,0) DEFAULT NULL,
  `bg_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `time` varchar(64) DEFAULT NULL,
  `sign_end` date DEFAULT NULL,
  `addr` varchar(1024) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT NULL,
  `audit` tinyint(2) DEFAULT '0',
  `closed` tinyint(2) DEFAULT '0',
  `sign_num` int(10) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT NULL,
  `template` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_activity`
-- -----------------------------
INSERT INTO `bao_activity` VALUES ('1', '1', '1', '1', '1', '1', '11', '活动标题', '你好，这个是活动介绍！', '2016/03/11/thumb_56e219fae020f.jpg', 'a:1:{i:0;s:34:\"2016/03/11/thumb_56e219fd9b1ea.jpg\";}', '<p>你好，这里是活动内容！</p>', '12', '2016-03-11', '2019-03-28', '2014年10月24日 7点半', '2018-03-15', '重庆大河村', '1', '1', '0', '2', '1457658395', '17.53.27.1', '');

-- -----------------------------
-- Table structure for `bao_activity_cate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_activity_cate`;
CREATE TABLE `bao_activity_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(32) DEFAULT NULL,
  `parent_id` tinyint(3) DEFAULT '0',
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_activity_cate`
-- -----------------------------
INSERT INTO `bao_activity_cate` VALUES ('1', '活动分类', '0', '1');

-- -----------------------------
-- Table structure for `bao_activity_sign`
-- -----------------------------
DROP TABLE IF EXISTS `bao_activity_sign`;
CREATE TABLE `bao_activity_sign` (
  `sign_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `num` int(5) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`sign_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_activity_sign`
-- -----------------------------
INSERT INTO `bao_activity_sign` VALUES ('1', '1', '148', '1', '13355888889', '测试号 ', '1457775425', '17.53.27.1');
INSERT INTO `bao_activity_sign` VALUES ('2', '1', '148', '1', '13355888889', '测试号 ', '1457775426', '17.53.27.1');

-- -----------------------------
-- Table structure for `bao_ad`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ad`;
CREATE TABLE `bao_ad` (
  `ad_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` smallint(6) DEFAULT '0',
  `city_id` smallint(5) unsigned DEFAULT '0',
  `title` varchar(64) DEFAULT NULL,
  `link_url` varchar(128) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `code` varchar(1024) DEFAULT NULL,
  `bg_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `closed` tinyint(1) DEFAULT '0',
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ad`
-- -----------------------------
INSERT INTO `bao_ad` VALUES ('1', '1', '1', 'BAOCMS发布啦', 'http://www.baocms.com', '2014/09/19/541c2c0a0a93b.jpg', '', '2014-09-18', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('2', '1', '1', '首页横幅广告', '#', '2014/09/19/541c44c9c5aec.gif', '', '2014-09-18', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('3', '3', '1', '演示婚庆1', '/shop/detail/shop_id/2.html', '2014/10/10/54374be48e09d.jpg', '', '2014-09-14', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('4', '3', '1', '演示婚庆2', '/shop/detail/shop_id/3.html', '2014/10/10/54374c8d7e8b1.jpg', '', '2014-10-09', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('5', '3', '1', '解馋牛排时尚牛排火锅', '/shop/detail/shop_id/41.html', '2014/10/10/543794a9c24d3.jpg', '', '2014-10-01', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('6', '3', '1', '家居广告1', '/shop/index/cat/7.html', '2014/10/10/54379e4d767bd.jpg', '', '2014-10-01', '2020-01-01', '1', '100');
INSERT INTO `bao_ad` VALUES ('7', '188', '1', '美食', '/mobile/shop/index/cat/1.html', '', '', '2014-11-15', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('8', '88', '1', '小吃快餐', '/mobile/shop/index/cat/2.html', '', '', '2014-11-15', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('9', '88', '1', '看电影', '/mobile/shop/index/cat/54.html', '', '', '2014-11-15', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('10', '88', '1', '找优惠', '/mobile/tuan/index.html', '', '', '2014-11-15', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('11', '88', '1', '订酒店', '/mobile/shop/index/cat/13.html', '', '', '2014-11-15', '2020-01-01', '0', '5');
INSERT INTO `bao_ad` VALUES ('12', '2', '1', '轮播1', 'http://www.5maiche.cn/list-83.html', '2015/10/05/56127a62be56d.jpg', '', '2014-11-15', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('13', '2', '1', '轮播2', 'http://www.5maiche.cn/list-83.html', '2015/10/05/56127a830f4bc.jpg', '', '2014-11-15', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('14', '2', '1', '美食', 'http://www.5maiche.cn/list-83.html', '2015/10/05/56127a9146f6f.jpg', '', '2014-11-15', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('15', '3', '1', '美丽人生婚礼顾问馆', '/mobile/shop/index/cat/2.html', '2014/11/18/546b2816677f9.jpg', '', '2014-11-18', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('16', '4', '1', '美丽人生婚礼顾问馆', '/shop/detail/shop_id/2.html', '2015/04/23/5538c6dae19c4.jpg', '', '2014-11-19', '2020-01-01', '0', '12');
INSERT INTO `bao_ad` VALUES ('17', '4', '1', '一人心婚礼造梦机构二周年庆典，精彩不断', '/shop/detail/shop_id/2.html', '2015/04/24/5539aca987408.jpg', '', '2014-11-11', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('18', '4', '1', '美丽人生婚礼顾问馆', '/shop/detail/shop_id/2.html', '2015/04/24/5539ac9b918e2.jpg', '', '2014-11-06', '2020-01-01', '0', '5');
INSERT INTO `bao_ad` VALUES ('19', '4', '1', '双11优惠券', '/shop/detail/shop_id/2.html', '2015/09/13/55f57eaa75b8a.jpg', '', '2014-11-06', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('20', '5', '1', '积分商城BANNER', '/shop/detail/shop_id/85.html', '2015/09/13/55f57d12e8a2d.jpg', '积分商城BANNER', '2014-11-20', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('21', '7', '1', 'PC首页广告', '/shop/detail/shop_id/30.html', '2015/04/24/5539af4a076f8.jpg', 'PC首页广告', '2014-11-20', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('22', '8', '1', '轮播广告', '/shop/detail/shop_id/55.html', '2015/04/23/5538bb2e90d19.jpg', '', '2014-11-21', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('23', '1', '1', '家政', 'http://baocms.fengmiyuanma.com/', '2015/11/22/5651c943dddf1.jpg', '', '2014-11-24', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('24', '7', '1', '首页广告3', 'http://www.baocms.com', '2014/11/27/547684ed9e88e.jpg', '', '2014-11-26', '2020-01-01', '1', '3');
INSERT INTO `bao_ad` VALUES ('25', '11', '1', '最新上线', 'http://www.baidu.com', '2014/12/29/54a121043953a.jpg', '', '2014-12-29', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('26', '9', '1', '品牌热区', 'http://www.jd.com', '2014/12/29/54a1216663781.png', '', '2014-12-15', '2020-01-01', '0', '34');
INSERT INTO `bao_ad` VALUES ('27', '10', '1', '风潮来袭', 'http://www.sina.com', '2014/12/29/54a1219463de0.png', '', '2014-12-04', '2020-01-01', '0', '100');
INSERT INTO `bao_ad` VALUES ('28', '9', '1', '品牌热区', 'http://www.baidu.com', '2014/12/29/54a1252dcb10e.png', '', '2014-12-22', '2020-01-01', '0', '11');
INSERT INTO `bao_ad` VALUES ('29', '13', '1', '蜀王烤鱼火锅怎么样', 'http://www.taobao.com', '2014/12/30/54a243123212b.png', '', '2014-12-29', '2020-01-01', '0', '34');
INSERT INTO `bao_ad` VALUES ('30', '12', '1', '蜀王烤鱼火锅', 'http://www.jd.com', '2014/12/30/54a24460e87b5.png', '', '2014-12-29', '2020-01-01', '0', '12');
INSERT INTO `bao_ad` VALUES ('31', '12', '1', '蜀王烤鱼火锅', 'http://www.google.cn/', '2014/12/30/54a2441d5319a.png', '', '2014-12-29', '2020-01-01', '0', '35');
INSERT INTO `bao_ad` VALUES ('32', '13', '1', '品牌热区', 'http://www.sina.com', '2014/12/30/54a242f2d1caa.png', '', '2014-12-29', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('33', '12', '1', '蜀王烤鱼火锅', 'http://www.qzone.qq.com', '2014/12/30/54a2448f3a145.png', '', '2014-12-28', '2020-01-01', '0', '100');
INSERT INTO `bao_ad` VALUES ('34', '14', '1', '商家新闻列表BANNER', '/shop/detail/shop_id/21.html', '2015/04/24/5539ade1809f4.jpg', '', '2015-01-05', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('35', '15', '1', '文章资讯列表页', '/shop/detail/shop_id/49.html', '2015/04/23/5538c5b08e194.jpg', '文章资讯列表页', '2015-01-06', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('36', '1', '1', '商家加盟', 'http://baocms.fengmiyuanma.com/', '2015/11/22/5651c6b3aa5ff.png', '', '2015-01-06', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('37', '5', '1', 'PC首页餐饮频道轮播广告', '/shop/detail/shop_id/85.html', '2016/02/27/56d1580e551c3.jpg', '', '2015-01-06', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('38', '17', '1', '下班去哪玩', '/tuan/detail/tuan_id/13.html', '2015/01/07/54ac9f5c1b483.jpg', '', '2015-01-05', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('39', '16', '1', '0元抽奖等你来', '/tuan/detail/tuan_id/12.html', '2015/04/23/5538c9268922f.jpg', '', '2015-01-06', '2020-01-01', '0', '12');
INSERT INTO `bao_ad` VALUES ('40', '16', '1', '0元抽奖等你来', '/shop/detail/shop_id/39.html', '2015/04/23/5538c60f8c405.jpg', '', '2015-01-06', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('41', '16', '1', '0元抽奖等你来', '/shop/detail/shop_id/39.html', '2015/04/23/5538c5ec81821.jpg', '', '2015-01-06', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('42', '16', '1', '0元抽奖等你来', '/shop/detail/shop_id/39.html', '2015/04/23/5538c5d598232.jpg', '', '2015-01-06', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('43', '17', '1', '下班去哪玩1', '/tuan/detail/tuan_id/13.html', '2015/01/07/54ac9f5c1b483.jpg', '', '2015-01-05', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('44', '17', '1', '下班去哪玩2', '/tuan/detail/tuan_id/13.html', '2015/01/07/54ac9f5c1b483.jpg', '', '2015-01-05', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('45', '17', '1', '活动', 'http://www.baocms.cn/huodong/detail/activity_id/16.html', '2015/04/28/553f333bc1a07.jpg', '', '2015-01-05', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('46', '18', '1', '优惠券轮播', '/coupon/detail/coupon_id/12.html', '2015/04/24/553a14654b69f.jpg', '', '2015-01-04', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('47', '18', '1', '优惠券轮播', '/coupon/detail/coupon_id/12.html', '2015/04/24/553a1459348a3.jpg', '', '2015-01-04', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('48', '19', '1', '优惠券轮播', '/coupon/detail/coupon_id/12.html', '2015/04/24/553a14462fe13.jpg', '', '2015-01-04', '2020-01-01', '1', '23');
INSERT INTO `bao_ad` VALUES ('49', '19', '1', 'PC生活信息首页横幅广告', 'http://www.baocms.cn/tuan/detail/tuan_id/2.html', '2015/04/24/553a149f57f17.jpg', '', '2015-01-13', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('50', '20', '1', '右侧二维码图片', '#', '2015/04/24/5539dd54ed0b5.jpg', '', '2015-01-13', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('51', '19', '1', '购物广告', '/mall/detail/goods_id/12.html', '2015/04/25/553af8986171e.jpg', '', '2015-01-12', '2020-01-01', '1', '12');
INSERT INTO `bao_ad` VALUES ('52', '5', '1', '品牌热区', '/shop/detail/shop_id/85.html', '2016/02/27/56d157ecc6834.jpg', '', '2015-01-04', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('53', '555', '1', 'PC活动首页轮播广告位', 'http://www.baocms.cn/mall/detail/goods_id/16.html', '2015/04/25/553af4fd56053.jpg', '', '2015-01-13', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('54', '22', '1', '汽车1', '/shop/detail/shop_id/118.html', '2015/10/17/56222f7f957b1.jpg', '', '2015-01-12', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('55', '22', '1', '结婚1', '/mobile/shop/index/cat/1.html', '2015/10/17/56222f75a43e6.jpg', '', '2015-01-12', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('56', '21', '1', '丽人3', '/shop/detail/shop_id/133.html', '2015/04/24/5539f3a0e1db2.jpg', '', '2015-01-12', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('57', '21', '1', '家居1', '/mobile/shop/index/cat/2.html', '2015/04/24/5539f3b6e49ad.jpg', '', '2015-01-12', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('58', '28', '1', '母婴1', '/shop/detail/shop_id/21.html', '2015/04/24/5539f3e0cb112.jpg', '', '2015-01-12', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('59', '29', '1', '培训1', '/shop/detail/shop_id/55.html', '2015/04/24/5539f485b1899.jpg', '', '2015-01-12', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('60', '22', '1', '餐饮广告2', '/shop/detail/shop_id/2.html', '2015/10/17/56222f6ada016.jpg', '', '2015-01-13', '2020-01-01', '0', '34');
INSERT INTO `bao_ad` VALUES ('61', '23', '1', '家具', '/huodong/detail/activity_id/16.html', '2015/04/27/553d91cd3f0b7.jpg', '', '2015-01-05', '2020-01-01', '0', '23');
INSERT INTO `bao_ad` VALUES ('62', '30', '1', '韩都衣舍', '/tuan/detail/tuan_id/5.html', '2015/01/16/54b8a2baa9d65.jpg', '', '2015-01-06', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('63', '30', '1', '巨一', '/tuan/detail/tuan_id/5.html', '2015/01/30/54cb3b4310ed6.png', '', '2015-01-06', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('64', '31', '1', '三鼎家政', '/tuan/detail/tuan_id/5.html', '2015/01/30/54cb3b600b9f4.png', '', '2015-01-06', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('65', '31', '1', '完美', '/tuan/detail/tuan_id/5.html', '2015/01/30/54cb3b77ab8f3.png', '', '2015-01-06', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('66', '31', '1', '生活家装饰', '/tuan/detail/tuan_id/5.html', '2015/01/30/54cb3cbea8d12.png', '', '2015-01-06', '2020-01-01', '0', '5');
INSERT INTO `bao_ad` VALUES ('67', '31', '1', 'LG', '/tuan/detail/tuan_id/5.html', '2015/01/30/54cb3ba231784.png', '', '2015-01-06', '2020-01-01', '0', '6');
INSERT INTO `bao_ad` VALUES ('68', '31', '1', '缤纷尚城', '/tuan/detail/tuan_id/5.html', '2015/01/30/54cb3bb35edfd.png', '', '2015-01-06', '2020-01-01', '0', '7');
INSERT INTO `bao_ad` VALUES ('69', '32', '1', 'PC一卡通', '#', '2015/10/23/56299f48ab982.jpg', '', '2015-01-17', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('70', '36', '1', '广告位', '/mall/detail/goods_id/1.html', '2015/01/17/54ba2dd9392a0.jpg', '', '2015-01-07', '2020-01-01', '1', '34');
INSERT INTO `bao_ad` VALUES ('71', '33', '1', '广告位', '/mall/detail/goods_id/1.html', '2015/10/09/561738b85ef8a.png', '', '2015-01-07', '2020-01-01', '0', '34');
INSERT INTO `bao_ad` VALUES ('72', '35', '1', '广告位', '/mall/detail/goods_id/1.html', '2015/04/25/553b2178c7231.jpg', '', '2015-01-07', '2020-01-01', '1', '34');
INSERT INTO `bao_ad` VALUES ('73', '33', '1', '广告位', '/mall/detail/goods_id/1.html', '2015/10/09/561738c8c11b8.png', '', '2015-01-07', '2020-01-01', '0', '34');
INSERT INTO `bao_ad` VALUES ('74', '7', '1', '4.0震撼发布', '/shop/detail/shop_id/30.html', '2015/04/24/5539af39aa4b1.jpg', '', '2015-01-26', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('75', '7', '1', 'Baocms4.0震撼来袭', '/shop/detail/shop_id/30.html', '2015/04/24/5539af1cdbb22.jpg', '', '2015-01-26', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('76', '1', '0', '全新商户中心', 'http://baocms.fengmiyuanma.com/store', '2016/03/22/56f0ead24bce0.jpg', '', '2015-01-26', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('77', '7', '1', 'Baocms震撼来袭', '/shop/detail/shop_id/29.html', '2016/02/27/56d159431e855.jpg', '', '2015-01-26', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('78', '7', '1', 'Baocms震撼来袭', '/shop/detail/shop_id/29.html', '2016/02/27/56d159383a339.png', '', '2015-01-26', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('79', '7', '1', 'Baocms震撼来袭', '/shop/detail/shop_id/29.html', '2016/02/27/56d1592bda769.jpg', '', '2015-01-26', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('80', '24', '1', 'Baocms震撼来袭', 'http://www.baocms.cn/jifen/main.html', '2015/04/24/5539d955ec5b6.jpg', '', '2015-01-26', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('81', '24', '1', 'Baocms震撼来袭', 'http://www.baocms.cn/jifen/main.html', '2015/04/24/5539da88cb0b5.jpg', '', '2015-01-26', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('82', '35', '1', 'Baocms震撼来袭', 'http://baocms.fengmiyuanma.com/', '2016/01/18/569c623473cb5.jpg', '', '2015-01-26', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('83', '24', '1', 'Baocms震撼来袭', 'http://baocms.cn/life/index.html', '2015/01/30/54cb56a29abac.png', '', '2015-01-26', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('84', '55', '1', '汽车2', '/shop/detail/shop_id/33.html', '2015/01/29/54c9fb4c679ad.png', '', '2015-01-12', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('85', '55', '1', '汽车3', '/shop/detail/shop_id/35.html', '2015/01/29/54c9fba36691a.png', '', '2015-01-12', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('86', '36', '1', '汽车4', '/shop/detail/shop_id/36.html', '2015/01/29/54ca01f60a6aa.png', '', '2015-01-20', '2020-01-01', '0', '86');
INSERT INTO `bao_ad` VALUES ('87', '34', '1', '汽车广告1', '/shop/detail/shop_id/38.html', '2015/01/29/54ca0698dff2e.png', '', '2015-01-30', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('88', '34', '1', '汽车广告2', '/shop/detail/shop_id/114.html', '2015/01/30/54cadcec28049.png', '', '2015-01-07', '2020-01-01', '0', '10');
INSERT INTO `bao_ad` VALUES ('89', '35', '1', '生活信息', '/life/detail/life_id/8.html', '2015/04/25/553b2178c7231.jpg', '', '2015-01-30', '2020-01-01', '1', '1');
INSERT INTO `bao_ad` VALUES ('90', '35', '1', '结婚广告2', '/shop/detail/shop_id/130.html', '2015/04/25/553b2178c7231.jpg', '', '2015-01-30', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('91', '36', '1', '丽人广告1', '#', '2015/04/25/553b259b83e3c.jpg', '', '2015-01-30', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('92', '36', '1', '丽人广告2', '/shop/detail/shop_id/50.html', '2015/01/30/54ca62dcf2694.png', '', '2015-01-30', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('93', '60', '1', '餐饮广告2', '/shop/detail/shop_id/11.html', '2015/09/13/55f57f70856d3.jpg', '<div style=\"width: 300px; height: 100px; float: left;\">\r\n\r\n                            <input type=\"hidden\" name=\"data[logo]\" value=\"<{$CONFIG.site.logo}>\" id=\"data_photo\" />\r\n\r\n                            <input id=\"photo_file\" name=\"photo_file\" type=\"file\" multiple=\"true\" value=\"\" />\r\n\r\n                        </div>', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('94', '3', '1', '餐饮广告3', '/shop/detail/shop_id/11.html', '2015/09/13/55f57f5b44ebb.jpg', '', '2015-01-01', '2020-01-01', '1', '3');
INSERT INTO `bao_ad` VALUES ('95', '3', '1', '餐饮广告4', '/shop/detail/shop_id/11.html', '2015/09/13/55f57f47d107c.jpg', '', '2015-01-01', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('96', '55', '1', '结婚2', '/shop/detail/shop_id/124.html', '2015/01/30/54cae2d2ad09b.png', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('97', '55', '1', '结婚3', '/shop/detail/shop_id/128.html', '2015/01/30/54cae387880c2.png', '', '2015-01-01', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('98', '25', '1', '结婚4', '/shop/detail/shop_id/8.html', '2015/01/30/54cae3c816eb1.png', '', '2015-01-01', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('99', '26', '1', '丽人2', '/shop/detail/shop_id/49.html', '2015/01/30/54cae95139b62.png', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('100', '26', '1', '丽人3', '/shop/detail/shop_id/50.html', '2015/01/30/54cae982f3cea.png', '', '2015-01-01', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('101', '26', '1', '丽人4', '/shop/detail/shop_id/52.html', '2015/01/30/54cae9c90003b.png', '', '2015-01-01', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('102', '27', '1', '家居2', '/shop/detail/shop_id/11.html', '2015/01/30/54caebb878f39.png', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('103', '27', '1', '家居3', '/shop/detail/shop_id/12.html', '2015/01/30/54caec129509f.png', '', '2015-01-01', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('104', '27', '1', '家居4', '/shop/detail/shop_id/17.html', '2015/01/30/54caec51dee7d.png', '', '2015-01-01', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('105', '37', '1', '家居广告1', '/shop/detail/shop_id/18.html', '2015/04/25/553b0e58b6c52.jpg', '', '2015-01-01', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('106', '37', '1', '家居广告2', '/shop/detail/shop_id/14.html', '2015/04/25/553b0e254774b.jpg', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('107', '28', '1', '母婴2', 'n/shop/detail/shop_id/28.html', '2015/01/30/54caf67d5dd4d.png', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('108', '28', '1', '母婴3', '/shop/detail/shop_id/27.html', '2015/01/30/54caf6b0588ce.png', '', '2015-01-01', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('109', '28', '1', '母婴4', '/shop/detail/shop_id/26.html', '2015/01/30/54cb046d8d07c.png', '', '2015-01-01', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('110', '38', '1', '电器', '/shop/index/cat/7.html', '2015/10/05/56128d0723ea5.jpg', '', '2015-01-01', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('111', '38', '1', '抢购', '/shop/detail/shop_id/76.html', '2015/10/05/56128cfbd816c.jpg', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('112', '29', '1', '培训2', '/shop/detail/shop_id/56.html', '2015/01/30/54cafabfd3c1b.png', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('113', '29', '1', '培训3', '/shop/detail/shop_id/57.html', '2015/01/30/54cb0185c18fb.png', '', '2015-01-01', '2020-01-01', '0', '3');
INSERT INTO `bao_ad` VALUES ('114', '30', '1', '培训4', '/shop/detail/shop_id/58.html', '2015/01/30/54cb01f2b5423.png', '', '2015-01-01', '2020-01-01', '0', '4');
INSERT INTO `bao_ad` VALUES ('115', '39', '1', '培训广告1', '/shop/detail/shop_id/59.html', '2015/01/30/54cafb4be3443.png', '', '2015-01-01', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('116', '39', '1', '培训广告2', '/shop/detail/shop_id/61.html', '2015/01/30/54cafb7e1e2b1.png', '', '2015-01-01', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('117', '33', '1', '商家主页广告', '/mall/main/order/1.html', '2015/04/25/553b32a7d10d3.jpg', '', '2015-02-24', '2020-01-01', '1', '2');
INSERT INTO `bao_ad` VALUES ('118', '40', '1', '商家主页广告', '/mall/main/order/1.html', '2015/04/25/553b3288cd71e.jpg', '', '2015-02-24', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('119', '40', '1', '商家主页广告', '/mall/detail/goods_id/23.html', '2015/04/25/553b327b07027.jpg', '', '2015-02-24', '2020-01-01', '0', '5');
INSERT INTO `bao_ad` VALUES ('120', '41', '1', '卖场首页广告', '/mobile/shop/index.html', '2015/02/25/54ed36763a34d.jpg', '', '2015-02-24', '2020-01-01', '0', '5');
INSERT INTO `bao_ad` VALUES ('121', '41', '1', '卖场首页广告', '/coupon/index/cat/1.html', '2015/04/25/553b3a47293b4.jpg', '', '2015-02-24', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('122', '41', '1', '卖场首页广告', '/coupon/index/cat/1.html', '2015/04/25/553b371052f6d.jpg', '', '2015-02-24', '2020-01-01', '0', '2');
INSERT INTO `bao_ad` VALUES ('123', '42', '1', '五周年庆典快来买吧', '/mall/detail/goods_id/1.html', '2015/04/27/553db004cce01.jpg', '', '2015-03-03', '2018-04-07', '0', '1');
INSERT INTO `bao_ad` VALUES ('124', '43', '1', '浪漫女装', '/mall/detail/goods_id/14.html', '2015/03/13/5502b9c7d194a.jpg', '', '2015-03-05', '2018-04-05', '0', '23');
INSERT INTO `bao_ad` VALUES ('125', '43', '1', '休闲皮鞋', '/mall/detail/goods_id/22.html', '2015/03/13/5502b9fb525eb.jpg', '', '2015-03-05', '2019-04-04', '0', '43');
INSERT INTO `bao_ad` VALUES ('126', '43', '1', '奥林巴斯微单相机', '/mall/detail/goods_id/13.html', '2015/03/13/5502ba3c3e094.jpg', '', '2015-03-05', '2019-03-26', '0', '23');
INSERT INTO `bao_ad` VALUES ('127', '43', '1', '化妆品', '/mall/detail/goods_id/15.html', '2015/03/13/5502ba8642bb5.jpg', '', '2015-03-05', '2019-04-04', '0', '11');
INSERT INTO `bao_ad` VALUES ('128', '43', '1', '兰芝真白新品上市', '/mall/detail/goods_id/16.html', '2015/03/13/5502bab9aa3bb.jpg', '', '2015-03-12', '2018-03-22', '0', '1');
INSERT INTO `bao_ad` VALUES ('129', '43', '1', '春季尚新精品男装', '/mall/detail/goods_id/17.html', '2015/03/13/5502baf1f1166.jpg', '', '2015-03-09', '2018-03-22', '0', '33');
INSERT INTO `bao_ad` VALUES ('130', '44', '1', '推荐商家1', '/mobile/ele/shop/shop_id/46.html', '2015/04/25/553b3eb989735.jpg', '', '2015-03-03', '2019-03-30', '0', '1');
INSERT INTO `bao_ad` VALUES ('131', '44', '1', '推荐商家2', '/mobile/ele/shop/shop_id/46.html', '2015/04/25/553b3f11a73ed.jpg', '', '2015-03-04', '2019-04-04', '0', '2');
INSERT INTO `bao_ad` VALUES ('132', '44', '1', '推荐商家3', '/shop/detail/shop_id/1.html', '2015/03/14/55038e97994ba.png', '', '2015-03-02', '2019-04-05', '1', '4');
INSERT INTO `bao_ad` VALUES ('133', '44', '1', '推荐商家4', '/shop/detail/shop_id/1.html', '2015/03/14/55038edb6e8a9.png', '', '2015-03-03', '2019-03-28', '1', '46');
INSERT INTO `bao_ad` VALUES ('134', '44', '1', '推荐商家5', '/shop/detail/shop_id/1.html', '2015/03/14/55038f0981fbd.png', '', '2015-03-02', '2018-03-29', '1', '88');
INSERT INTO `bao_ad` VALUES ('135', '45', '1', '生活日用', '#', '2015/04/25/553afbae79f32.jpg', '', '2015-03-03', '2019-03-27', '0', '1');
INSERT INTO `bao_ad` VALUES ('136', '46', '1', '附近工作', '#', '2015/04/25/553afc4dbcdf0.jpg', '', '2015-03-03', '2019-03-25', '0', '23');
INSERT INTO `bao_ad` VALUES ('137', '47', '1', '笔记本电脑', '/mall/detail/goods_id/10.html', '2015/03/14/55039e9dcf293.jpg', '', '2015-03-02', '2019-03-26', '0', '3');
INSERT INTO `bao_ad` VALUES ('138', '47', '1', '大屏手机', '/mall/detail/goods_id/9.html', '2015/03/14/55039ebff115c.jpg', '', '2015-03-11', '2019-03-26', '0', '5');
INSERT INTO `bao_ad` VALUES ('139', '47', '1', '泸州老窖白酒', '/mall/detail/goods_id/8.html', '2015/03/14/55039eea25928.jpg', '', '2015-03-04', '2019-03-27', '0', '45');
INSERT INTO `bao_ad` VALUES ('140', '47', '1', '电饭锅', '/mall/detail/goods_id/8.html', '2015/03/14/55039f08ae3ac.jpg', '', '2015-03-03', '2019-03-25', '0', '7');
INSERT INTO `bao_ad` VALUES ('141', '48', '1', '2F左侧', '/mall/index/cate_id/14.html', '2015/04/25/553b278189b33.jpg', '', '2015-03-24', '2023-03-24', '0', '24');
INSERT INTO `bao_ad` VALUES ('142', '49', '1', '2F中间', '/mall/detail/goods_id/10.html', '2015/03/24/5511295e3f1a3.jpg', '', '2015-03-11', '2019-03-29', '0', '43');
INSERT INTO `bao_ad` VALUES ('143', '50', '1', '3F左侧', '/mall/index/cate_id/2.html', '2015/03/24/55112a77dc5b0.png', '', '2015-03-06', '2019-03-27', '0', '1');
INSERT INTO `bao_ad` VALUES ('144', '51', '1', '3F中间', '/mall/detail/goods_id/16.html', '2015/03/24/55112aa2deaa4.jpg', '', '2015-03-05', '2019-03-28', '0', '4');
INSERT INTO `bao_ad` VALUES ('145', '25', '1', 'PC活动首页轮播广告位', 'http://www.baocms.cn/mall/detail/goods_id/16.html', '2015/04/25/553af4cc07f06.jpg', '', '2015-01-13', '2020-01-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('146', '8', '1', '教育', '/shop/detail/shop_id/55.html', '2015/04/23/5538bb4f9ef3c.jpg', '', '2015-04-08', '2015-06-16', '0', '2');
INSERT INTO `bao_ad` VALUES ('147', '8', '1', '教育', '/shop/detail/shop_id/55.html', '2015/04/23/5538bba766128.jpg', '', '2015-04-02', '2015-08-12', '0', '3');
INSERT INTO `bao_ad` VALUES ('148', '14', '1', '母婴', '/shop/detail/shop_id/21.html', '2015/04/24/5539adcf0f924.jpg', '', '2015-04-01', '2015-06-26', '1', '1');
INSERT INTO `bao_ad` VALUES ('149', '14', '1', '母婴', '/shop/detail/shop_id/21.html', '2015/04/24/5539adbce04d6.jpg', '', '2015-04-09', '2015-08-23', '1', '2');
INSERT INTO `bao_ad` VALUES ('150', '15', '1', '母婴', '/shop/detail/shop_id/49.html', '2015/04/23/5538c890914bd.jpg', '', '2015-04-02', '2015-08-23', '0', '2');
INSERT INTO `bao_ad` VALUES ('151', '15', '1', '丽人', '/shop/detail/shop_id/49.html', '2015/04/23/5538c8d36260a.jpg', '', '2015-04-02', '2015-07-23', '0', '1');
INSERT INTO `bao_ad` VALUES ('152', '19', '1', '锅', 'http://www.baocms.cn/tuan/detail/tuan_id/2.html', '2015/04/24/553a14d12b3a8.jpg', '', '2015-04-01', '2015-07-08', '1', '2');
INSERT INTO `bao_ad` VALUES ('153', '19', '1', '优惠', 'http://www.baocms.cn/tuan/detail/tuan_id/2.html', '2015/09/13/55f57de98ce81.png', '', '2015-04-03', '2015-07-24', '0', '2');
INSERT INTO `bao_ad` VALUES ('154', '19', '1', '核桃', 'http://www.baocms.cn/tuan/detail/tuan_id/2.html', '2015/09/13/55f57dcadff97.png', '', '2015-04-09', '2015-06-24', '0', '2');
INSERT INTO `bao_ad` VALUES ('155', '21', '1', '抢购', 'http://www.baocms.cn/mall/detail/goods_id/16.html', '2015/04/28/553f35820675d.jpg', '', '2015-04-09', '2015-08-06', '1', '1');
INSERT INTO `bao_ad` VALUES ('156', '48', '1', '生活信息', '/mall/index/cate_id/14.html', '2015/04/25/553b279abfc36.jpg', '', '2015-04-09', '2015-07-25', '0', '1');
INSERT INTO `bao_ad` VALUES ('157', '48', '1', '生活信息', '/mall/index/cate_id/14.html', '2015/04/25/553b27b5d5deb.jpg', '', '2015-04-08', '2015-06-27', '0', '1');
INSERT INTO `bao_ad` VALUES ('158', '48', '1', '生活信息', '/mall/index/cate_id/14.html', '2015/04/25/553b27d3cd7fd.jpg', '', '2015-04-10', '2015-06-24', '0', '1');
INSERT INTO `bao_ad` VALUES ('159', '48', '1', '生活信息', '/mall/index/cate_id/14.html', '2015/04/25/553b27f619505.jpg', '', '2015-04-03', '2015-07-31', '0', '1');
INSERT INTO `bao_ad` VALUES ('160', '48', '1', '生活信息', 'http://www.baocms.cn/mall/index/cate_id/14.html', '2015/04/25/553b28905b305.jpg', '', '2015-04-11', '2015-06-11', '0', '1');
INSERT INTO `bao_ad` VALUES ('161', '42', '1', '浪奇高端除菌洗衣液4斤促销装', '/mall/detail/goods_id/75.html', '2015/04/27/553dad170a01c.jpg', '', '2015-04-27', '2018-04-27', '0', '2');
INSERT INTO `bao_ad` VALUES ('162', '42', '1', '慕尼思丹茶几客厅家具', '/mall/detail/goods_id/84.html', '2015/04/27/553daf3c83fc1.jpg', '', '2015-04-27', '2018-04-27', '0', '3');
INSERT INTO `bao_ad` VALUES ('163', '23', '1', '万里挑一，为你而选', '/coupon/detail/coupon_id/18.html', '2015/10/17/562231e983db0.jpg', '', '2015-04-28', '2018-04-28', '0', '24');
INSERT INTO `bao_ad` VALUES ('164', '23', '1', 'BAOCMS家居频道诚意奉献', '/coupon/detail/coupon_id/5.html', '2015/10/17/562231dea6d60.jpg', '', '2015-04-28', '2018-04-28', '0', '25');
INSERT INTO `bao_ad` VALUES ('165', '17', '1', '超级囤货日，童装玩具全场满减', '/huodong/detail/activity_id/20.html', '2015/04/28/553f3025011ad.jpg', '', '2015-04-28', '2018-04-28', '0', '2');
INSERT INTO `bao_ad` VALUES ('166', '17', '1', '清仓四连发，底价1-4折', '/huodong/detail/activity_id/26.html', '2015/04/28/553f31adb993f.jpg', '', '2015-04-28', '2018-04-28', '0', '35');
INSERT INTO `bao_ad` VALUES ('167', '21', '1', '五月亲子节，深情钜惠', '/mall/detail/goods_id/16.html', '2015/04/28/553f34dc85803.jpg', '', '2015-04-28', '2018-04-28', '1', '2');
INSERT INTO `bao_ad` VALUES ('168', '21', '1', '儿童节', 'http://www.baocms.cn/mall/detail/goods_id/78.html', '2015/10/17/56222fea2a541.jpg', '', '2015-04-22', '2015-06-26', '0', '1');
INSERT INTO `bao_ad` VALUES ('169', '21', '1', '大换购', 'http://www.baocms.cn/mall/detail/goods_id/13.html', '2015/10/17/56222fdabca0c.jpg', '', '2015-04-15', '2016-06-03', '0', '1');
INSERT INTO `bao_ad` VALUES ('170', '52', '1', '大换购', '#', '2015/06/24/558a649ac8152.jpg', '', '2015-06-24', '2019-06-19', '0', '1');
INSERT INTO `bao_ad` VALUES ('171', '52', '1', 'php微信O2O生活宝门户系统', '#', '2015/06/24/558a648d1ba8f.jpg', '', '2015-06-16', '2015-06-27', '0', '2');
INSERT INTO `bao_ad` VALUES ('172', '2', '1', 'hao', 'http://www.baidu.com', '2015/07/07/559ba90dae9d9.png', 'hao', '2015-07-15', '2015-07-24', '1', '1');
INSERT INTO `bao_ad` VALUES ('173', '14', '0', '外卖', '#', '2015/09/01/55e5469928d22.png', '', '2015-09-01', '2019-10-04', '0', '1');
INSERT INTO `bao_ad` VALUES ('174', '57', '1', '手机首页', 'http://baocms.5maiche.cn/', '2015/10/08/5615ffd428769.jpg', '', '2015-10-08', '2019-11-07', '1', '1');
INSERT INTO `bao_ad` VALUES ('175', '57', '1', '手机首页', 'http://baocms.fengmiyuanma.com/', '2015/12/21/5677840ae7c21.jpg', '', '2015-10-08', '2018-10-19', '1', '2');
INSERT INTO `bao_ad` VALUES ('176', '22', '0', '餐饮广告2', '/shop/detail/shop_id/2.html', '2015/10/17/56222f8b6edde.jpg', '', '2015-10-17', '2018-10-30', '0', '6');
INSERT INTO `bao_ad` VALUES ('177', '21', '0', '餐饮广告2', '/shop/detail/shop_id/2.html', '2015/10/17/5622302b43bdd.jpg', '', '2015-10-17', '2019-10-17', '0', '3');
INSERT INTO `bao_ad` VALUES ('178', '57', '0', '手机首页', 'http://baocms.fengmiyuanma.com/', '2016/01/17/569af4c1dd7af.jpg', '', '2015-12-20', '2019-12-25', '0', '0');
INSERT INTO `bao_ad` VALUES ('179', '59', '0', '登录页面', 'http://baocms.fengmiyuanma.com/', '2016/01/15/5698826845272.jpg', '', '2015-12-30', '2019-12-26', '0', '0');
INSERT INTO `bao_ad` VALUES ('180', '6', '0', '品牌热区', '/shop/detail/shop_id/85.html', '2016/02/27/56d158dd4cfcd.jpg', '', '2016-02-27', '2020-02-27', '0', '1');
INSERT INTO `bao_ad` VALUES ('181', '6', '0', '品牌热区', '/shop/detail/shop_id/85.html', '2016/02/27/56d158f021a10.png', '', '2016-02-27', '2020-02-27', '0', '2');
INSERT INTO `bao_ad` VALUES ('182', '6', '0', '品牌热区', '/shop/detail/shop_id/85.html', '2016/02/27/56d159061128b.jpg', '', '2016-02-27', '2020-02-27', '0', '3');
INSERT INTO `bao_ad` VALUES ('183', '60', '0', 'PC一元云购', 'http://baocms.fengmiyuanma.com/', '2016/03/01/56d55e00172bb.png', '', '2016-03-01', '2020-03-01', '0', '1');
INSERT INTO `bao_ad` VALUES ('184', '1', '0', '蜂蜜源码', 'http://baocms.fengmiyuanma.com/worker', '2016/03/22/56f0ed8916a74.jpg', '', '2016-03-22', '2020-03-25', '0', '2');
INSERT INTO `bao_ad` VALUES ('185', '1', '0', '蜂蜜源码', 'http://baocms.fengmiyuanma.com/wuye', '2016/03/23/56f2b2037e9d1.jpg', '', '2016-03-23', '2020-03-19', '0', '1');

-- -----------------------------
-- Table structure for `bao_ad_site`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ad_site`;
CREATE TABLE `bao_ad_site` (
  `site_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(32) DEFAULT NULL,
  `site_name` varchar(64) DEFAULT NULL,
  `site_type` tinyint(1) DEFAULT NULL,
  `site_place` smallint(5) DEFAULT '0',
  PRIMARY KEY (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ad_site`
-- -----------------------------
INSERT INTO `bao_ad_site` VALUES ('1', 'default', 'PC首页热门关注轮播图片广告位', '2', '1');
INSERT INTO `bao_ad_site` VALUES ('2', 'default', 'PC首页右侧轮播图片广告位', '2', '1');
INSERT INTO `bao_ad_site` VALUES ('3', 'default', 'PC活动首页轮播图片广告位', '2', '3');
INSERT INTO `bao_ad_site` VALUES ('4', 'default', 'PC上门服务图片广告位', '2', '4');
INSERT INTO `bao_ad_site` VALUES ('5', 'default', 'PC商城首页3张轮播750*300', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('6', 'default', 'PC商城首页3张轮播下面250*100广告3张（1）上', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('7', 'default', 'PC商城首页3张轮播下面250*170广告3张（2）下', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('8', 'default', 'PC同城优购主页1楼图片广告', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('9', 'default', 'PC同城优购主页2楼图片广告', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('10', 'default', 'PC同城优购主页3楼图片广告', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('11', 'default', 'PC同城优购主页4楼图片广告', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('12', 'default', 'PC同城优购主页5楼图片广告', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('13', 'default', 'PC同城优购主页6楼图片广告', '2', '5');
INSERT INTO `bao_ad_site` VALUES ('14', 'default', 'PC外卖首页轮播图片广告位', '2', '6');
INSERT INTO `bao_ad_site` VALUES ('15', 'default', 'PC订座首页右侧轮播图片广告', '2', '7');
INSERT INTO `bao_ad_site` VALUES ('16', 'default', 'PC订座列表右侧轮播图片广告', '2', '7');
INSERT INTO `bao_ad_site` VALUES ('17', 'default', 'PC订座新单右侧轮播图片广告', '2', '7');
INSERT INTO `bao_ad_site` VALUES ('18', 'default', 'PC订座热门右侧轮播图片广告', '2', '7');
INSERT INTO `bao_ad_site` VALUES ('19', 'default', 'PC同城信息主页头部轮播图片广告位', '2', '8');
INSERT INTO `bao_ad_site` VALUES ('20', 'default', 'PC同城信息主页右侧轮播图片广告位', '2', '8');
INSERT INTO `bao_ad_site` VALUES ('21', 'default', 'PC同城信息主页底部轮播图片广告位', '2', '8');
INSERT INTO `bao_ad_site` VALUES ('22', 'default', 'PC同城信息首页右侧轮播图片广告位', '2', '8');
INSERT INTO `bao_ad_site` VALUES ('23', 'default', 'PC优惠券首页轮播图片广告位', '2', '9');
INSERT INTO `bao_ad_site` VALUES ('24', 'default', 'PC积分商城首页轮播图片广告位', '2', '11');
INSERT INTO `bao_ad_site` VALUES ('25', 'default', 'PC专题1首页图片广告位', '2', '13');
INSERT INTO `bao_ad_site` VALUES ('26', 'default', 'PC专题2首页图片广告位', '2', '13');
INSERT INTO `bao_ad_site` VALUES ('27', 'default', 'PC专题3首页图片广告位', '2', '13');
INSERT INTO `bao_ad_site` VALUES ('28', 'default', 'PC专题4首页图片广告位', '2', '13');
INSERT INTO `bao_ad_site` VALUES ('29', 'default', 'PC专题5首页图片广告位', '2', '13');
INSERT INTO `bao_ad_site` VALUES ('30', 'default', '手机同城优购首页轮播广告位', '2', '18');
INSERT INTO `bao_ad_site` VALUES ('31', 'default', '手机家政首页图片广告位', '2', '19');
INSERT INTO `bao_ad_site` VALUES ('32', 'default', '手机优惠券首页轮播图片广告位', '2', '23');
INSERT INTO `bao_ad_site` VALUES ('33', 'default', '手机社区详情页轮播图片广告位', '2', '24');
INSERT INTO `bao_ad_site` VALUES ('34', 'default', '手机卖场首页轮播图片广告位', '2', '25');
INSERT INTO `bao_ad_site` VALUES ('35', 'default', '手机微店列表页轮播图片广告位', '2', '29');
INSERT INTO `bao_ad_site` VALUES ('36', 'default', '手机附近工作图片广告位', '2', '32');
INSERT INTO `bao_ad_site` VALUES ('37', 'default', '手机APP首页轮播图片广告位', '2', '33');
INSERT INTO `bao_ad_site` VALUES ('38', 'default', 'PC酒店首页幻灯', '2', '34');
INSERT INTO `bao_ad_site` VALUES ('56', 'default', 'PC首页顶部广告', '2', '1');
INSERT INTO `bao_ad_site` VALUES ('57', 'default', 'WAP手机首页广告', '1', '14');
INSERT INTO `bao_ad_site` VALUES ('58', 'default', '444455', '2', '1');
INSERT INTO `bao_ad_site` VALUES ('59', 'default', 'PC登录注册广告', '2', '33');
INSERT INTO `bao_ad_site` VALUES ('60', 'default', 'PC一元云购首页轮播', '1', '12');

-- -----------------------------
-- Table structure for `bao_admin`
-- -----------------------------
DROP TABLE IF EXISTS `bao_admin`;
CREATE TABLE `bao_admin` (
  `admin_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) DEFAULT NULL,
  `password` char(32) DEFAULT NULL,
  `role_id` smallint(5) DEFAULT NULL,
  `city_id` smallint(6) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `last_time` int(11) DEFAULT NULL,
  `last_ip` varchar(20) DEFAULT NULL,
  `is_ip` tinyint(1) NOT NULL DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_admin`
-- -----------------------------
INSERT INTO `bao_admin` VALUES ('1', 'admin', '7fef6171469e80d32c0559f88b377245', '1', '0', '15000000000', '1441886203', '127.0.0.1', '1459265002', '27.13.24.17', '1', '0');
INSERT INTO `bao_admin` VALUES ('5', 'demo', '8ddcff3a80f4189ca1c9d4d902c3c909', '1', '0', '13355895566', '1450145726', '17.53.153.38', '1459069642', '218.56.42.27', '1', '0');
INSERT INTO `bao_admin` VALUES ('6', 'ceshi', 'cc17c30cd111c7215fc8f51f8790e0e1', '2', '1', '13356782345', '1456631504', '17.53.31.218', '1459255213', '120.35.164.80', '0', '0');
INSERT INTO `bao_admin` VALUES ('7', '测试1', '49d92f4ddd6164663ed8fe915d915dc9', '2', '0', '13355666666', '1456740370', '17.53.154.172', '0', '', '0', '1');
INSERT INTO `bao_admin` VALUES ('8', 'ceshi1', '9464c3798239e316379036767f0ff7d1', '2', '7', '13366776677', '1456740406', '17.53.154.172', '1459255676', '120.35.164.80', '0', '0');

-- -----------------------------
-- Table structure for `bao_area`
-- -----------------------------
DROP TABLE IF EXISTS `bao_area`;
CREATE TABLE `bao_area` (
  `area_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` smallint(5) DEFAULT '0',
  `area_name` varchar(32) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_area`
-- -----------------------------
INSERT INTO `bao_area` VALUES ('1', '1', '瑶海', '1');
INSERT INTO `bao_area` VALUES ('2', '1', '新站', '2');
INSERT INTO `bao_area` VALUES ('3', '1', '包河', '3');
INSERT INTO `bao_area` VALUES ('4', '1', '政务', '4');
INSERT INTO `bao_area` VALUES ('5', '1', '庐阳', '5');
INSERT INTO `bao_area` VALUES ('6', '1', '蜀山', '6');
INSERT INTO `bao_area` VALUES ('7', '1', '滨湖', '7');
INSERT INTO `bao_area` VALUES ('8', '1', '高新', '8');
INSERT INTO `bao_area` VALUES ('9', '1', '肥东', '9');
INSERT INTO `bao_area` VALUES ('10', '7', '白沟镇', '10');
INSERT INTO `bao_area` VALUES ('24', '7', '雁塔区', '1');

-- -----------------------------
-- Table structure for `bao_around`
-- -----------------------------
DROP TABLE IF EXISTS `bao_around`;
CREATE TABLE `bao_around` (
  `around_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `type` tinyint(1) DEFAULT '0' COMMENT '1代表常去，2代表我家，3代表公司',
  `name` varchar(128) DEFAULT NULL,
  `lng` varchar(15) DEFAULT NULL,
  `lat` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`around_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_article`
-- -----------------------------
DROP TABLE IF EXISTS `bao_article`;
CREATE TABLE `bao_article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL,
  `cate_id` smallint(5) DEFAULT '0',
  `city_id` smallint(5) DEFAULT NULL,
  `area_id` smallint(5) DEFAULT NULL,
  `shop_id` int(10) NOT NULL DEFAULT '0',
  `source` varchar(32) DEFAULT NULL,
  `profiles` text,
  `keywords` varchar(256) DEFAULT NULL,
  `orderby` tinyint(4) NOT NULL DEFAULT '100',
  `photo` varchar(128) DEFAULT NULL,
  `details` text,
  `istop` int(2) NOT NULL DEFAULT '0',
  `isroll` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `views` int(11) DEFAULT '0',
  `zan` int(6) NOT NULL DEFAULT '0',
  `closed` tinyint(2) NOT NULL DEFAULT '0',
  `valuate` tinyint(2) DEFAULT '0',
  `audit` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_article`
-- -----------------------------
INSERT INTO `bao_article` VALUES ('1', '&lt;{$CONFIG.site.title}&gt;', '2', '1', '1', '1', '红网', '文章简介', 'baocms', '100', '2016/01/13/thumb_5695bafa18bdb.png', '<p>测试下呗！</p><p><br/></p><include file=\"public:header\"><div class=\"mainBt\"><ul><li class=\"li1\">设置</li><li class=\"li2\">基本设置</li><li class=\"li2 li3\">站点设置</li></ul></div><p class=\"attention\"><span>注意：</span>这个设置和全局有关系</p><div class=\"mainScAdd\"><div class=\"tableBox\"><table bordercolor=\"#dbdbdb\" cellspacing=\"0\" width=\"100%\" border=\"1px\" style=\" border-collapse: collapse; margin:0px; vertical-align:middle; background-color:#FFF;\"><tbody><tr><td class=\"lfTdBt\">站点名称：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[sitename]\" value=\"&lt;{$CONFIG.site.sitename}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>注意这个不是网站的Title，一般建议是网站的品牌名</code></td></tr><tr><td class=\"lfTdBt\">站点网址：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[host]\" value=\"&lt;{$CONFIG.site.host}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>例如：http://www.baocms.cn 如果你在二级目录下面就需要带上二级目录</code></td></tr><tr><td class=\"lfTdBt\">图片域名：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[imgurl]\" value=\"&lt;{$CONFIG.site.imgurl}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>例如：http://www.baocms.cn 一般情况下是和站点网址一样，如果做了CDN加速一般就可能是其他的域名</code></td></tr><tr><td class=\"lfTdBt\">android下载地址：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[android]\" value=\"&lt;{$CONFIG.site.android}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>android下载地址</code></td></tr><tr><td class=\"lfTdBt\">IOS下载地址：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[ios]\" value=\"&lt;{$CONFIG.site.ios}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>IOS下载地址</code></td></tr><tr><td class=\"lfTdBt\">LOGO：</td><td class=\"rgTdBt\"><div style=\"width: 300px; height: 100px; float: left;\"><input type=\"hidden\" name=\"data[logo]\" value=\"&lt;{$CONFIG.site.logo}&gt;\" id=\"data_photo\"/><input id=\"photo_file\" name=\"photo_file\" type=\"file\" multiple=\"true\" value=\"\"/></div><div style=\"width: 300px; height: 100px; float: left;\"><img id=\"photo_img\" width=\"200\" height=\"80\" src=\"__ROOT__/attachs/<{$CONFIG.site.logo|default=\'default.jpg\'}>\"/></div>＜script type=\"text/javascript\" src=\"__PUBLIC__/js/uploadify/jquery.uploadify.min.js?t=<{$nowtime}＞\">＜/script＞＜link rel=\"stylesheet\" href=\"__PUBLIC__/js/uploadify/uploadify.css\"/＞＜script＞$(\"#photo_file\").uploadify({ \'swf\': \'__PUBLIC__/js/uploadify/uploadify.swf?t=<{$nowtime}>\', \'uploader\': \'<{:U(\"app/upload/uploadify\",array(\"model\"=>\"setting\"))}>\', \'cancelImg\': \'__PUBLIC__/js/uploadify/uploadify-cancel.png\', \'buttonText\': \'上传网站LOGO\', \'fileTypeExts\': \'*.gif;*.jpg;*.png\', \'queueSizeLimit\': 1, \'onUploadSuccess\': function (file, data, response) { $(\"#data_photo\").val(data); $(\"#photo_img\").attr(\'src\', \'__ROOT__/attachs/\' + data).show(); } });＜/script＞</td></tr><tr><td class=\"lfTdBt\">微信二维码：</td><td class=\"rgTdBt\"><div style=\"width: 300px; height: 100px; float: left;\"><input type=\"hidden\" name=\"data[wxcode]\" value=\"&lt;{$CONFIG.site.wxcode}&gt;\" id=\"data_wxcode\"/><input id=\"wxcode_file\" name=\"wxcode_file\" type=\"file\" multiple=\"true\" value=\"\"/></div><div style=\"width: 300px; height: 100px; float: left;\"><img id=\"wxcode_img\" width=\"100\" height=\"100\" src=\"__ROOT__/attachs/<{$CONFIG.site.wxcode|default=\'default.jpg\'}>\"/></div>＜script＞$(\"#wxcode_file\").uploadify({ \'swf\': \'__PUBLIC__/js/uploadify/uploadify.swf?t=<{$nowtime}>\', \'uploader\': \'<{:U(\"app/upload/uploadify\",array(\"model\"=>\"setting\"))}>\', \'cancelImg\': \'__PUBLIC__/js/uploadify/uploadify-cancel.png\', \'buttonText\': \'上传微信二维码\', \'fileTypeExts\': \'*.gif;*.jpg;*.png\', \'queueSizeLimit\': 1, \'onUploadSuccess\': function (file, data, response) { $(\"#data_wxcode\").val(data); $(\"#wxcode_img\").attr(\'src\', \'__ROOT__/attachs/\' + data).show(); } });＜/script＞</td></tr><tr><td class=\"lfTdBt\">客服QQ：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[qq]\" value=\"&lt;{$CONFIG.site.qq}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>前台模板显示调用！</code></td></tr><tr><td class=\"lfTdBt\">电话：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[tel]\" value=\"&lt;{$CONFIG.site.tel}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>前台模板显示调用！</code></td></tr><tr><td class=\"lfTdBt\">邮件：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[email]\" value=\"&lt;{$CONFIG.site.email}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>前台模板显示调用！</code></td></tr><tr><td class=\"lfTdBt\">ICP备案：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[icp]\" value=\"&lt;{$CONFIG.site.icp}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>前台模板显示调用！</code></td></tr><tr><td class=\"lfTdBt\">站点标题：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[title]\" value=\"&lt;{$CONFIG.site.title}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>seo设置中调用</code></td></tr><tr><td class=\"lfTdBt\">站点关键字：</td><td class=\"rgTdBt\"><textarea name=\"data[keyword]\" cols=\"50\" rows=\"5\">&lt;{$config.site.keyword}&gt;&lt;/{$config.site.keyword}&gt;</textarea><code>seo设置中调用，建议认真填写！</code></td></tr><tr><td class=\"lfTdBt\">站点描述：</td><td class=\"rgTdBt\"><textarea name=\"data[description]\" cols=\"50\" rows=\"5\">&lt;{$config.site.description}&gt;&lt;/{$config.site.description}&gt;</textarea><code>seo设置中调用</code></td></tr><tr><td class=\"lfTdBt\">网站头部信息：</td><td class=\"rgTdBt\"><textarea name=\"data[headinfo]\" cols=\"150\" rows=\"8\">&lt;{$config.site.headinfo}&gt;&lt;/{$config.site.headinfo}&gt;</textarea><code>首页顶部的信息在这里删除！一般情况下无需填写！</code></td></tr><tr><td class=\"lfTdBt\">统计代码：</td><td class=\"rgTdBt\"><textarea name=\"data[tongji]\" cols=\"50\" rows=\"5\">&lt;{$config.site.tongji}&gt;&lt;/{$config.site.tongji}&gt;</textarea><code>模板中调用，有统计代码的填写在这里。</code></td></tr><tr><td class=\"lfTdBt\">默认城市：</td><td class=\"rgTdBt\"><select name=\"data[city_id]\" class=\"selectOption\"><!--?php citys=\"\" as=\"\"-->&lt;option <!--?php echo=\"\" selected=\"selected\"-->value=&quot;&lt;{$val.city_id}&gt;&quot;&gt;&lt;{$val.name}&gt;<!--?php--><!--?php--><!--{$val.name}--><!--{$val.city_id}--><!--?php--><!--?php--></select><code>请填写您的默认城市。</code></td></tr><tr><td class=\"lfTdBt\" style=\"padding-right: 0px;\">城市中心地图坐标：</td><td class=\"rgTdBt\">经度<input type=\"text\" name=\"data[lng]\" value=\"&lt;{$CONFIG.site.lng}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;纬度<input type=\"text\" name=\"data[lat]\" value=\"&lt;{$CONFIG.site.lat}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>关系到全局默认，请认真填写！</code></td></tr><tr><td class=\"lfTdBt\">自动收货时间：</td><td class=\"rgTdBt\">商城<input type=\"text\" name=\"data[goods]\" value=\"&lt;{$CONFIG.site.goods}&gt;\" style=\"width: 50px;\" class=\"scAddTextName \"/>（天） &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;外卖<input type=\"text\" name=\"data[ele]\" value=\"&lt;{$CONFIG.site.ele}&gt;\" style=\"width: 50px;\" class=\"scAddTextName \"/>（小时）</td></tr><tr><td class=\"lfTdBt\">整合UCENTER：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[ucenter]&quot;<eq name=\"CONFIG.site.ucenter\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[ucenter]&quot; &nbsp;<eq name=\"CONFIG.site.ucenter\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启这个需要先在UCENTER接口配置先配置好！</code></td></tr><tr><td class=\"lfTdBt\">贴吧发帖免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[postaudit]&quot;<eq name=\"CONFIG.site.postaudit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[postaudit]&quot; &nbsp;<eq name=\"CONFIG.site.postaudit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启之后帖子发布免审核！</code></td></tr><tr><td class=\"lfTdBt\">贴吧回帖免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[replyaudit]&quot;<eq name=\"CONFIG.site.replyaudit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[replyaudit]&quot; &nbsp;<eq name=\"CONFIG.site.replyaudit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启之后帖子发布免审核！</code></td></tr><tr><td class=\"lfTdBt\">小区发帖免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[xiaoqu_post_audit]&quot;<eq name=\"CONFIG.site.xiaoqu_post_audit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[xiaoqu_post_audit]&quot; &nbsp;<eq name=\"CONFIG.site.xiaoqu_post_audit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启之后小区帖子发布免审核！</code></td></tr><tr><td class=\"lfTdBt\">小区回帖免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[xiaoqu_reply_audit]&quot;<eq name=\"CONFIG.site.xiaoqu_reply_audit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[xiaoqu_reply_audit]&quot; &nbsp;<eq name=\"CONFIG.site.xiaoqu_reply_audit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启之后小区回帖发布免审核！</code></td></tr><tr><td class=\"lfTdBt\">新闻评论免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[article_reply_audit]&quot;<eq name=\"CONFIG.site.article_reply_audit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[article_reply_audit]&quot; &nbsp;<eq name=\"CONFIG.site.article_reply_audit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启后新闻评论免审核！小心使用！</code></td></tr><tr><td class=\"lfTdBt\">物业发送通知免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[xiaoqu_news_audit]&quot;<eq name=\"CONFIG.site.xiaoqu_news_audit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[xiaoqu_news_audit]&quot; &nbsp;<eq name=\"CONFIG.site.xiaoqu_news_audit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启之后物业发送通知免审核，自己看吧，怕就不要开启自动！</code></td></tr><tr><td class=\"lfTdBt\">手机端发布约会免审核：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[hdmobile_hdfabu_audit]&quot;<eq name=\"CONFIG.site.hdmobile_hdfabu_audit\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[hdmobile_hdfabu_audit]&quot; &nbsp;<eq name=\"CONFIG.site.hdmobile_hdfabu_audit\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启手机端发布的约会会员发布后即可显示无需审核！小心使用！</code></td></tr><tr><td class=\"lfTdBt\">微信自动绑定：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[weixin]&quot;<eq name=\"CONFIG.site.weixin\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[weixin]&quot; &nbsp;<eq name=\"CONFIG.site.weixin\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;不开启</label><code>开启后微信端会自动跳转到绑定账号，如果已经绑定账号将自动登录！</code></td></tr><tr><td class=\"lfTdBt\">城市编号：</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[citycode]\" value=\"&lt;{$CONFIG.site.citycode}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>联系www.fengmiyuanma.com获取，自动采集商家用的！</code></td></tr><!--分销开始--><tr><td class=\"lfTdBt\">拥有分销权限用户最低等级：</td><td class=\"rgTdBt\"><select name=\"data[profit_min_rank_id]\" class=\"seleFl w200\"><option value=\"0\">不限制</option>&lt;option selected=&quot;selected&quot;value=&quot;&lt;{$item.rank_id}&gt;&quot;&gt;&lt;{$item.rank_name}&gt;<!--{$item.rank_name}--><!--{$item.rank_id}--></select></td></tr><tr><td class=\"lfTdBt\">推荐时效：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"1\" max=\"1000\" name=\"data[profit_expire]\" value=\"&lt;{$CONFIG.site.profit_expire}&gt;\" class=\"scAddTextName \"/>小时<code>访问者点击某推荐人的网址后，在此时间段内注册、下单，均认为是该推荐人所介绍的</code></td></tr><tr><td class=\"lfTdBt\">一级会员注册分成积分数：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"0\" max=\"1000\" name=\"data[profit_integral1]\" value=\"&lt;{$CONFIG.site.profit_integral1}&gt;\" class=\"scAddTextName \"/></td></tr><tr><td class=\"lfTdBt\">二级会员注册分成积分数：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"0\" max=\"1000\" name=\"data[profit_integral2]\" value=\"&lt;{$CONFIG.site.profit_integral2}&gt;\" class=\"scAddTextName \"/></td></tr><tr><td class=\"lfTdBt\">三级会员注册分成积分数：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"0\" max=\"1000\" name=\"data[profit_integral3]\" value=\"&lt;{$CONFIG.site.profit_integral3}&gt;\" class=\"scAddTextName \"/></td></tr><tr><td class=\"lfTdBt\">一级会员订单分成比例：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"0\" max=\"100\" name=\"data[profit_rate1]\" value=\"&lt;{$CONFIG.site.profit_rate1}&gt;\" class=\"scAddTextName \"/>%</td></tr><tr><td class=\"lfTdBt\">二级会员订单分成比例：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"0\" max=\"100\" name=\"data[profit_rate2]\" value=\"&lt;{$CONFIG.site.profit_rate2}&gt;\" class=\"scAddTextName \"/>%</td></tr><tr><td class=\"lfTdBt\">三级会员订单分成比例：</td><td class=\"rgTdBt\"><input type=\"number\" min=\"0\" max=\"100\" name=\"data[profit_rate3]\" value=\"&lt;{$CONFIG.site.profit_rate3}&gt;\" class=\"scAddTextName \"/>%</td></tr><!--分销结束--><tr><td class=\"lfTdBt\">全局通知手机号码</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[config_mobile]\" value=\"&lt;{$CONFIG.site.config_mobile}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>填写有有的场景需要通知给管理员的手机号！</code></td></tr><tr><td class=\"lfTdBt\">全局通知邮箱</td><td class=\"rgTdBt\"><input type=\"text\" name=\"data[config_email]\" value=\"&lt;{$CONFIG.site.config_email}&gt;\" class=\"scAddTextName \"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<code>这里是在必要情况下，给站长发邮箱的时候的接受信箱。</code></td></tr><tr><td class=\"lfTdBt\">是否关闭网站：</td><td class=\"rgTdBt\"><label>&lt;input type=&quot;radio&quot; name=&quot;data[web_close]&quot;<eq name=\"CONFIG.site.web_close\" value=\"1\">checked=&quot;checked&quot;</eq>value=&quot;1&quot; &nbsp;/&gt;开启</label><label>&lt;input type=&quot;radio&quot; name=&quot;data[web_close]&quot; &nbsp;<eq name=\"CONFIG.site.web_close\" value=\"0\">checked=&quot;checked&quot;</eq>value=&quot;0&quot; &nbsp;/&gt;关闭</label><code style=\"color:#F00\">关闭之后前台打不开哦，突发情况以及备案的时候可以关闭，其他时候不要去动！关闭后不影响后台跟商家后台！</code></td></tr><tr><td class=\"lfTdBt\">关闭网站原因：</td><td class=\"rgTdBt\"><textarea name=\"data[web_close_title]\" cols=\"50\" rows=\"4\">&lt;{$config.site.web_close_title}&gt;&lt;/{$config.site.web_close_title}&gt;</textarea><code>这里填写关站原因，将会显示到前台首页！</code></td></tr></tbody></table></div><div class=\"smtQr\"><input type=\"submit\" value=\"确认保存\" class=\"smtQrIpt\"/></div></div><include file=\"public:footer\"></include></include>', '0', '1', '1452653721', '127.0.0.1', '482', '0', '1', '0', '0');
INSERT INTO `bao_article` VALUES ('2', '环境监测演练强能力', '2', '1', '1', '1', '红网', '环境监测人员正在监测水质各项指标', 'ceshi', '100', '2016/03/21/thumb_56eeec335c67b.jpg', '<p>环境监测演练强能力</p>', '1', '1', '1456469206', '17.53.31.218', '666', '0', '0', '0', '1');
INSERT INTO `bao_article` VALUES ('3', '为什么要购买此版本运营？', '2', '1', '1', '1', '裕合园时尚宾馆', '目前市场上的O2O源码众多，为什么单独选择此版本，看看截图就知道了，新版集成了多城市分站、一元云购、三级分销、新版家政、新版社区、新版物流、新版商家中心、新版wap物业中心、抵用券、拼团、数据库维护、更好的性价比为你保驾护航！ 【这都不是关键，关键是无bug，完整无错客户体验非常好】', 'Baocms', '100', '', '2222222222222', '1', '0', '1456731766', '17.53.154.172', '6289', '0', '0', '1', '1');
INSERT INTO `bao_article` VALUES ('4', '', '0', '0', '0', '0', '', '', '', '100', '', '', '0', '0', '0', '', '0', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('5', '3333333333', '42', '0', '0', '1', '', '', '', '100', '2016/03/16/thumb_56e8dc46c6bc3.jpg', '<p>33333333333333</p>', '0', '0', '1458101320', '17.53.27.1', '1', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('6', '蜂蜜源码', '3', '1', '0', '1', '', '呜呜呜呜呜呜', '多个关键字用', '100', '2016/03/16/thumb_56e8eb4489362.jpg', '<p><span style=\"color: rgb(51, 51, 51); line-height: 30px; text-align: right; white-space: normal;\">详细内容</span></p>', '0', '0', '1458105351', '17.53.27.1', '0', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('7', '蜂蜜源码', '3', '1', '1', '1', '1', '222222222', '多个关键字用', '100', '2016/03/16/thumb_56e8ecb4ae424.jpg', '<p>222222222222222222222222</p>', '0', '0', '1458105526', '17.53.27.1', '0', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('8', '蜂蜜源码', '2', '1', '1', '1', '裕合园时尚宾馆', '2222', '多个关键字用', '100', '2016/03/16/thumb_56e8ede536e04.jpg', '<p>888888</p>', '0', '0', '1458105832', '17.53.27.1', '0', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('9', '蜂蜜源码', '3', '1', '1', '1', '裕合园时尚宾馆', '2222', '222', '100', '', '<p>2222</p>', '0', '0', '1458106224', '17.53.27.1', '17', '0', '0', '0', '1');
INSERT INTO `bao_article` VALUES ('10', '1111', '3', '1', '1', '1', '裕合园时尚宾馆', '11111', '222', '100', '2016/03/16/thumb_56e8efa4abe19.jpg', '<p>1111111111</p>', '0', '0', '1458106279', '17.53.27.1', '14', '0', '0', '0', '1');
INSERT INTO `bao_article` VALUES ('11', '飘逸系带雪纺衫X3113', '3', '1', '1', '1', '裕合园时尚宾馆', '文章简介', '选择文章分类', '100', '2016/03/16/thumb_56e8f20c7a625.jpg', '<p><img src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/25/thumb_56f42714048f1.jpg\" _src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/25/thumb_56f42714048f1.jpg\"/></p>', '0', '0', '1458106899', '17.53.27.1', '23', '0', '1', '0', '1');
INSERT INTO `bao_article` VALUES ('12', 'wap商家中心添加', '3', '1', '1', '1', '裕合园时尚宾馆', '你好，简介！', '新闻', '100', '2016/03/17/thumb_56ea0ced0ec3f.jpg', '<p>文章内容</p>', '0', '0', '1458179331', '17.53.28.68', '0', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('13', 'wap商家中心添加', '3', '1', '1', '1', '裕合园时尚宾馆', '你好，简介！', '新闻', '100', '2016/03/17/thumb_56ea0ced0ec3f.jpg', '文章内容', '0', '0', '1458179331', '17.53.28.68', '0', '0', '0', '0', '0');
INSERT INTO `bao_article` VALUES ('14', '你好', '3', '1', '1', '1', '裕合园时尚宾馆', '日你', '你', '100', '2016/03/17/thumb_56ea0de084303.jpg', '太牛逼', '0', '0', '1458179565', '17.53.28.68', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `bao_article_cate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_article_cate`;
CREATE TABLE `bao_article_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(32) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_article_cate`
-- -----------------------------
INSERT INTO `bao_article_cate` VALUES ('1', '新闻', '0', '1');
INSERT INTO `bao_article_cate` VALUES ('2', '重庆大事记', '1', '1');
INSERT INTO `bao_article_cate` VALUES ('3', '重庆民生', '2', '1');

-- -----------------------------
-- Table structure for `bao_article_comment`
-- -----------------------------
DROP TABLE IF EXISTS `bao_article_comment`;
CREATE TABLE `bao_article_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '上级评论id,若是一级评论则为0',
  `nickname` varchar(100) DEFAULT NULL COMMENT '评论人昵称',
  `user_id` int(11) DEFAULT NULL COMMENT '评论人UID',
  `post_id` int(11) DEFAULT NULL COMMENT '新闻编号',
  `content` text COMMENT '评论内容',
  `zan` int(6) NOT NULL DEFAULT '0',
  `cai` int(6) NOT NULL DEFAULT '0',
  `create_time` int(11) DEFAULT NULL COMMENT '评论或回复发表时间',
  `create_ip` varchar(20) NOT NULL,
  `audit` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_article_comment`
-- -----------------------------
INSERT INTO `bao_article_comment` VALUES ('1', '0', '测试号', '148', '1', '你好，不错！', '15', '0', '1452944919', '17.53.155.230', '1');
INSERT INTO `bao_article_comment` VALUES ('2', '0', '测试号', '148', '1', 'wap测试回复功能！', '10', '0', '1452945076', '17.53.155.230', '1');
INSERT INTO `bao_article_comment` VALUES ('3', '0', '测试号', '148', '1', '测试', '8', '0', '1453019034', '1.86.1.39', '1');
INSERT INTO `bao_article_comment` VALUES ('4', '0', '测试号', '148', '1', '回复', '4', '0', '1453492809', '222.222.150.82', '1');
INSERT INTO `bao_article_comment` VALUES ('5', '0', '测试号', '148', '2', '12月7日至8日，我市环境监测系统在盐边县国胜乡开展了突发环境事件应急监测演练，共有来自全市5个环境监测站的70余人参加。此次演练，进一步提高了环境监测部门应对环境突发事件的快速反应和应急处置实战能力。', '18', '1', '1456474420', '17.53.31.218', '1');
INSERT INTO `bao_article_comment` VALUES ('6', '0', '测试号', '148', '2', '你好，这个新闻页面还不错，我很喜欢。', '4', '1', '1456558131', '17.53.31.218', '1');
INSERT INTO `bao_article_comment` VALUES ('7', '0', '测试号', '148', '2', '不错啊！', '4', '0', '1456558311', '17.53.31.218', '1');
INSERT INTO `bao_article_comment` VALUES ('8', '0', '测试号', '148', '2', '不错啊！', '2', '2', '1456558460', '17.53.31.218', '1');
INSERT INTO `bao_article_comment` VALUES ('9', '0', '测试号', '148', '2', '不错啊！', '3', '0', '1456558625', '17.53.31.218', '1');
INSERT INTO `bao_article_comment` VALUES ('10', '0', '2382526623@qq.com', '264', '2', '哦距离', '0', '0', '1458574202', '124.231.136.218', '1');

-- -----------------------------
-- Table structure for `bao_award`
-- -----------------------------
DROP TABLE IF EXISTS `bao_award`;
CREATE TABLE `bao_award` (
  `award_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `type` enum('shark','scratch','lottery') DEFAULT NULL COMMENT '摇一摇 刮刮卡  抽奖大转盘',
  `explain` varchar(1024) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `is_online` tinyint(1) DEFAULT '0' COMMENT '1就是在线状态了',
  PRIMARY KEY (`award_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_award`
-- -----------------------------
INSERT INTO `bao_award` VALUES ('1', '测试', '2', 'lottery', '测试', '2016-01-21', '1453031879', '1.86.1.146', '1');
INSERT INTO `bao_award` VALUES ('2', 'ceshi', '1', 'lottery', 'ceshgi', '2016-02-12', '1454674595', '182.100.136.130', '1');
INSERT INTO `bao_award` VALUES ('3', '测试3级分类商品', '1', 'shark', '11111', '2016-02-29', '1456448455', '218.8.201.189', '1');

-- -----------------------------
-- Table structure for `bao_award_goods`
-- -----------------------------
DROP TABLE IF EXISTS `bao_award_goods`;
CREATE TABLE `bao_award_goods` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `award_id` int(11) DEFAULT NULL,
  `award_name` varchar(32) DEFAULT NULL,
  `goods_name` varchar(64) DEFAULT NULL,
  `prob` int(11) DEFAULT '0' COMMENT '数值越大概率越低',
  `num` int(11) DEFAULT '0',
  `surplus` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_id`),
  KEY `award_id` (`award_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_award_goods`
-- -----------------------------
INSERT INTO `bao_award_goods` VALUES ('1', '3', '1', '1', '1', '1', '1');

-- -----------------------------
-- Table structure for `bao_award_share`
-- -----------------------------
DROP TABLE IF EXISTS `bao_award_share`;
CREATE TABLE `bao_award_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `award_id` int(11) DEFAULT NULL,
  `is_used` tinyint(4) DEFAULT '0' COMMENT '1代表抽过奖了',
  `ip` varchar(15) DEFAULT NULL,
  `num` int(11) DEFAULT '0' COMMENT '点击的数量',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`,`award_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_award_share`
-- -----------------------------
INSERT INTO `bao_award_share` VALUES ('1', '1', '1', '222.222.150.82', '0');
INSERT INTO `bao_award_share` VALUES ('2', '3', '0', '218.8.201.189', '0');

-- -----------------------------
-- Table structure for `bao_award_winning`
-- -----------------------------
DROP TABLE IF EXISTS `bao_award_winning`;
CREATE TABLE `bao_award_winning` (
  `winning_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `award_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `randstr` varchar(6) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`winning_id`),
  KEY `award_id` (`award_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_bill_cate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_bill_cate`;
CREATE TABLE `bao_bill_cate` (
  `cate_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(128) DEFAULT '0',
  `orderby` tinyint(3) DEFAULT '100',
  `photo` varchar(128) DEFAULT NULL,
  `closed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_bill_order`
-- -----------------------------
DROP TABLE IF EXISTS `bao_bill_order`;
CREATE TABLE `bao_bill_order` (
  `bill_order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT '0',
  `city_id` smallint(5) unsigned DEFAULT '0',
  `area_id` smallint(5) unsigned DEFAULT '0',
  `mobile` varchar(11) DEFAULT NULL,
  `realname` varchar(20) DEFAULT NULL,
  `account` varchar(50) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `sum` int(10) unsigned DEFAULT '0',
  `money` int(10) unsigned DEFAULT '0',
  `interest` decimal(15,2) unsigned DEFAULT '0.00',
  `create_time` int(11) unsigned DEFAULT '0',
  `create_ip` varchar(15) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0' COMMENT '0等待处理  1代表已成功  2代表已退款',
  `admin_id` int(11) unsigned DEFAULT '0',
  `admin_time` int(11) unsigned DEFAULT '0',
  `admin_memo` varchar(255) DEFAULT NULL,
  `bill_type_id` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bill_order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_bill_shop`
-- -----------------------------
DROP TABLE IF EXISTS `bao_bill_shop`;
CREATE TABLE `bao_bill_shop` (
  `bill_id` int(10) NOT NULL AUTO_INCREMENT,
  `list_id` int(10) DEFAULT NULL,
  `shop_id` int(10) DEFAULT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  `votenum` int(11) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`bill_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_bill_type`
-- -----------------------------
DROP TABLE IF EXISTS `bao_bill_type`;
CREATE TABLE `bao_bill_type` (
  `bill_type_id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `bill_type_name` varchar(20) DEFAULT NULL,
  `bill_fields` varchar(255) DEFAULT NULL,
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sms_notify` tinyint(1) DEFAULT NULL,
  `fee_rate` decimal(10,2) unsigned DEFAULT '0.00',
  `integral` int(11) unsigned DEFAULT '0',
  `bill_fields_label` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `areas` text,
  PRIMARY KEY (`bill_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_bill_type`
-- -----------------------------
INSERT INTO `bao_bill_type` VALUES ('1', '物业费', 'realname,mobile,account', '1', '1', '0.00', '1', '业主姓名,手机,物业编号', '目前这收费项目、代缴物业费，缴费成功短信通知您！', '1,2,3,4,5,6,7,8,9,10,12,11,13,14,15,16,17,18');
INSERT INTO `bao_bill_type` VALUES ('3', '交警罚款', 'realname,account', '1', '0', '0.00', '1', '车牌号码,,处罚决定书编号', '请认真核对您处罚决定书编号，对照填写。', '12,13,14,15,16,17,18,19,20,21,22,23,24');

-- -----------------------------
-- Table structure for `bao_bill_vote`
-- -----------------------------
DROP TABLE IF EXISTS `bao_bill_vote`;
CREATE TABLE `bao_bill_vote` (
  `vote_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `bill_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_billboard`
-- -----------------------------
DROP TABLE IF EXISTS `bao_billboard`;
CREATE TABLE `bao_billboard` (
  `list_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL,
  `intro` varchar(128) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `cate_id` int(10) DEFAULT NULL,
  `looknum` int(11) DEFAULT '0',
  `orderby` int(10) DEFAULT '100',
  `closed` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `is_hot` tinyint(1) DEFAULT '0',
  `is_new` tinyint(1) DEFAULT NULL,
  `is_chose` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_business`
-- -----------------------------
DROP TABLE IF EXISTS `bao_business`;
CREATE TABLE `bao_business` (
  `business_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `business_name` varchar(32) DEFAULT NULL,
  `area_id` smallint(5) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  `is_hot` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`business_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_business`
-- -----------------------------
INSERT INTO `bao_business` VALUES ('1', '生态公园', '2', '1', '1');
INSERT INTO `bao_business` VALUES ('2', '胜利广场', '1', '2', '0');
INSERT INTO `bao_business` VALUES ('3', '和平广场', '1', '1', '1');
INSERT INTO `bao_business` VALUES ('4', '大东门', '1', '3', '1');
INSERT INTO `bao_business` VALUES ('5', '长江批发市场', '1', '11', '0');
INSERT INTO `bao_business` VALUES ('6', '车站', '1', '12', '1');
INSERT INTO `bao_business` VALUES ('7', '胜利路', '1', '7', '1');
INSERT INTO `bao_business` VALUES ('8', '七里塘', '1', '8', '1');
INSERT INTO `bao_business` VALUES ('9', '三孝口', '5', '13', '1');
INSERT INTO `bao_business` VALUES ('10', '双岗', '1', '14', '1');
INSERT INTO `bao_business` VALUES ('11', '逍遥津', '1', '1', '1');
INSERT INTO `bao_business` VALUES ('12', '步行街', '1', '2', '1');
INSERT INTO `bao_business` VALUES ('13', '安医附院', '6', '56', '0');
INSERT INTO `bao_business` VALUES ('14', '天鹅湖', '4', '23', '0');
INSERT INTO `bao_business` VALUES ('15', '大铺头', '6', '58', '0');
INSERT INTO `bao_business` VALUES ('16', '宁国路', '3', '99', '0');
INSERT INTO `bao_business` VALUES ('17', '国购广场', '6', '12', '0');
INSERT INTO `bao_business` VALUES ('18', '滨湖世纪城', '7', '0', '0');
INSERT INTO `bao_business` VALUES ('19', '湿地公园', '7', '0', '0');
INSERT INTO `bao_business` VALUES ('21', '万达广场', '4', '22', '0');
INSERT INTO `bao_business` VALUES ('24', '测试', '11', '100', '0');
INSERT INTO `bao_business` VALUES ('25', '测试', '11', '100', '0');
INSERT INTO `bao_business` VALUES ('26', '测试', '11', '100', '0');
INSERT INTO `bao_business` VALUES ('27', '测试', '11', '100', '0');
INSERT INTO `bao_business` VALUES ('28', '安庆下面的商家111', '22', '22', '1');
INSERT INTO `bao_business` VALUES ('29', '安庆下面的商家11122', '22', '32', '0');
INSERT INTO `bao_business` VALUES ('30', '黔江下面的商圈111', '20', '32', '1');
INSERT INTO `bao_business` VALUES ('31', '黔江下面的商圈2222222', '20', '35', '1');
INSERT INTO `bao_business` VALUES ('32', '火车北站', '23', '1', '1');
INSERT INTO `bao_business` VALUES ('33', '汽车站', '10', '1', '1');
INSERT INTO `bao_business` VALUES ('35', '西安的商圈', '24', '1', '0');

-- -----------------------------
-- Table structure for `bao_city`
-- -----------------------------
DROP TABLE IF EXISTS `bao_city`;
CREATE TABLE `bao_city` (
  `city_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `pinyin` varchar(32) DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT '0',
  `lng` varchar(15) DEFAULT NULL,
  `lat` varchar(15) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  `first_letter` char(1) DEFAULT NULL,
  `theme` varchar(21) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_city`
-- -----------------------------
INSERT INTO `bao_city` VALUES ('7', '西安', 'xian', '1', '104.071189', '30.576419', '2', 'X', 'default');
INSERT INTO `bao_city` VALUES ('9', '白沟', 'baigou', '1', '116.030336', '39.126934', '1', 'B', 'red');
INSERT INTO `bao_city` VALUES ('1', '温江区', 'chongqingshi', '1', '108.111754', '29.355971', '9', 'C', 'default');
INSERT INTO `bao_city` VALUES ('10', '大连', 'dalian', '1', '121.615642', '38.917549', '0', 'D', 'default');

-- -----------------------------
-- Table structure for `bao_cloud_goods`
-- -----------------------------
DROP TABLE IF EXISTS `bao_cloud_goods`;
CREATE TABLE `bao_cloud_goods` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(10) DEFAULT '0' COMMENT '0表示后台发布',
  `city_id` int(10) DEFAULT '0',
  `area_id` int(10) DEFAULT '0',
  `type` tinyint(1) DEFAULT '0' COMMENT '1表示1元夺宝，2代表5元夺宝，3代表10元夺宝',
  `title` varchar(64) DEFAULT '',
  `intro` varchar(255) DEFAULT '',
  `details` text,
  `join` int(10) DEFAULT '0' COMMENT '已参与',
  `price` int(10) DEFAULT '0' COMMENT '总价格',
  `max` int(10) DEFAULT '0' COMMENT '该件商品最大允许的参与数',
  `settlement_price` int(10) DEFAULT '0',
  `photo` varchar(128) DEFAULT '',
  `thumb` text,
  `status` tinyint(4) DEFAULT '0' COMMENT '0表示正在云购中，1表示已结束',
  `win_user_id` int(10) DEFAULT '0' COMMENT '中奖UID',
  `win_number` int(10) DEFAULT '0' COMMENT '中奖编号',
  `closed` tinyint(1) DEFAULT '0',
  `audit` tinyint(1) DEFAULT '0',
  `lottery_time` int(10) DEFAULT '0' COMMENT '开奖时间',
  `create_time` int(10) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT '',
  PRIMARY KEY (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_cloud_goods`
-- -----------------------------
INSERT INTO `bao_cloud_goods` VALUES ('11', '1', '1', '1', '1', 'Apple iPhone6s Plus 128G 颜色随机', '封面简介', '<p>很不错！<br/></p><p><br/></p><p><img src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/01/thumb_56d55cc876441.jpg\" _src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/01/thumb_56d55cc876441.jpg\" style=\"\"/></p><p><img src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/01/thumb_56d55ccd504d1.jpg\" _src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/01/thumb_56d55ccd504d1.jpg\" style=\"\"/></p><p><img src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/01/thumb_56d55cd0e5ea7.jpg\" _src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/01/thumb_56d55cd0e5ea7.jpg\" style=\"\"/></p><p><br/></p>', '10', '10', '5', '900', '2016/03/01/thumb_56d5594138edd.jpg', 'a:1:{i:0;s:34:\"2016/03/01/thumb_56d5594497a13.jpg\";}', '1', '148', '10000002', '0', '1', '1456824298', '1456823460', '17.53.154.172');
INSERT INTO `bao_cloud_goods` VALUES ('12', '1', '1', '4', '3', '雅马哈跑车', '新款可上牌地平线大跑车 大型摩托车 重型机车150-350CC水冷', '<p><span style=\"LINE-HEIGHT: 21px; FONT-FAMILY: &#39;microsoft yahei&#39;; WHITE-SPACE: normal; FLOAT: none; COLOR: rgb(221,39,39)\">二年超长质保 无理退货 全国可上牌 全国联保</span> </p>', '22', '1000', '20', '90000', '2016/03/01/thumb_56d57fd3bfbda.jpg', 'a:1:{i:0;s:34:\"2016/03/01/thumb_56d57fd5891f6.jpg\";}', '0', '0', '0', '0', '1', '0', '1456832488', '17.53.154.172');

-- -----------------------------
-- Table structure for `bao_cloud_logs`
-- -----------------------------
DROP TABLE IF EXISTS `bao_cloud_logs`;
CREATE TABLE `bao_cloud_logs` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `num` int(10) DEFAULT '0',
  `create_time` int(10) DEFAULT '0',
  `microtime` varchar(3) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT '',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_cloud_logs`
-- -----------------------------
INSERT INTO `bao_cloud_logs` VALUES ('108', '11', '148', '2', '1456824145', '273', '17.53.154.172');
INSERT INTO `bao_cloud_logs` VALUES ('109', '11', '148', '3', '1456824239', '675', '17.53.154.172');
INSERT INTO `bao_cloud_logs` VALUES ('110', '11', '227', '5', '1456824298', '872', '17.53.154.172');
INSERT INTO `bao_cloud_logs` VALUES ('111', '12', '227', '2', '1456833388', '351', '17.53.154.172');
INSERT INTO `bao_cloud_logs` VALUES ('112', '12', '148', '10', '1458311203', '923', '182.105.174.254');
INSERT INTO `bao_cloud_logs` VALUES ('113', '12', '148', '10', '1458311211', '997', '182.105.174.254');

-- -----------------------------
-- Table structure for `bao_community`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community`;
CREATE TABLE `bao_community` (
  `community_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0' COMMENT '物业管理员',
  `city_id` smallint(5) DEFAULT NULL,
  `area_id` smallint(5) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `addr` varchar(128) DEFAULT NULL,
  `tel` varchar(20) NOT NULL,
  `pic` varchar(64) NOT NULL,
  `village_id` smallint(5) DEFAULT NULL,
  `property` varchar(128) DEFAULT NULL COMMENT '物业',
  `lng` varchar(15) DEFAULT NULL,
  `lat` varchar(15) DEFAULT NULL,
  `closed` tinyint(1) DEFAULT '0',
  `orderby` tinyint(4) DEFAULT '100',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`community_id`),
  KEY `city_id` (`city_id`,`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='小区表';

-- -----------------------------
-- Records of `bao_community`
-- -----------------------------
INSERT INTO `bao_community` VALUES ('1', '148', '1', '1', '杨光花园', '重庆市合川区', '13355892345', '2016/01/15/569880741f413.jpg', '1', '重庆市杨光物业管理有限公司', '106.557435', '29.569536', '0', '2', '1452679719', '17.53.26.254');
INSERT INTO `bao_community` VALUES ('2', '228', '1', '1', '青春家园', '重庆市大合区新田路123号', '023-76452346', '2016/01/18/569c5e024e9f8.jpg', '1', '康乐物业管理有限公司', '108.210136', '30.039958', '0', '2', '1453088294', '17.53.155.189');

-- -----------------------------
-- Table structure for `bao_community_ad`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_ad`;
CREATE TABLE `bao_community_ad` (
  `ad_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) DEFAULT NULL,
  `title` varchar(64) DEFAULT '',
  `link_url` varchar(128) DEFAULT '',
  `photo` varchar(128) DEFAULT '',
  `orderby` tinyint(1) DEFAULT '100',
  `create_time` int(10) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT '',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_ad`
-- -----------------------------
INSERT INTO `bao_community_ad` VALUES ('1', '1', '妞的推广广告', 'http://www.baidu.com', '2016/01/18/569c6ae0d1331.jpg', '10', '1452681153', '60.222.163.166');
INSERT INTO `bao_community_ad` VALUES ('2', '1', '6933', 'www.baidu.com', '2016/03/14/56e66a6bd3917.jpg', '1', '1457941112', '219.146.252.174');
INSERT INTO `bao_community_ad` VALUES ('3', '1', '444444', 'http://baocms.fengmiyuanma.com/', '2016/03/23/thumb_56f23844ba62a.jpg', '33', '1458714654', '17.53.28.68');
INSERT INTO `bao_community_ad` VALUES ('4', '1', '小美厨', 'www.ledi.com.cn', '2016/03/27/thumb_56f7e2c87382c.jpg', '1', '1459086056', '59.62.111.32');

-- -----------------------------
-- Table structure for `bao_community_news`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_news`;
CREATE TABLE `bao_community_news` (
  `news_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `intro` varchar(1024) DEFAULT NULL,
  `details` text,
  `views` int(11) DEFAULT '0',
  `audit` tinyint(1) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_news`
-- -----------------------------
INSERT INTO `bao_community_news` VALUES ('5', '1', '后台添加通知', '简介', '内容', '2', '0', '0', '1453287436', '17.53.155.189');
INSERT INTO `bao_community_news` VALUES ('2', '1', '停水1月1日22', '就是停水了222', '某某单元某某某某单元某某某某单元某某某某单元某某某某单元某某某某单元某某某某单元某某某某单元某某某某单元某某某某单元某某 某某单元某某 某某单元某某 某某单元某某某某单元2某某222 某某单元某某', '538', '1', '0', '1453287277', '17.53.155.189');
INSERT INTO `bao_community_news` VALUES ('6', '1', '免审核', '11', '11111', '13', '1', '0', '1453288196', '17.53.155.189');
INSERT INTO `bao_community_news` VALUES ('7', '1', '火热的o2o源码', '近期非常火热的o2o源码... ', '近期非常火热的o2o源码,... 近期非常火热的o2o源码,baocms 5.1最新黄金版地方上火商城系统,咱们这里分享的是一键安装版哦,100%完全免费下载,目前网上都是叫卖RMB', '8', '1', '1', '1457939652', '219.146.252.174');
INSERT INTO `bao_community_news` VALUES ('8', '1', 'wap测试', '编辑后重申', '222222', '0', '0', '0', '1458709880', '17.53.28.68');

-- -----------------------------
-- Table structure for `bao_community_order`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_order`;
CREATE TABLE `bao_community_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) DEFAULT NULL,
  `order_date` char(7) DEFAULT '2015-10',
  `user_id` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_order`
-- -----------------------------
INSERT INTO `bao_community_order` VALUES ('2', '1', '2016-03', '148', '1458006741', '17.53.27.1');
INSERT INTO `bao_community_order` VALUES ('3', '1', '2016-03', '231', '1458716044', '17.53.28.68');
INSERT INTO `bao_community_order` VALUES ('4', '1', '2016-04', '231', '1458719041', '17.53.28.68');
INSERT INTO `bao_community_order` VALUES ('5', '1', '点击选择年/月', '231', '1458983613', '220.182.49.84');

-- -----------------------------
-- Table structure for `bao_community_order_logs`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_order_logs`;
CREATE TABLE `bao_community_order_logs` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `money` int(10) DEFAULT '0',
  `type` tinyint(1) DEFAULT '0',
  `create_time` int(10) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT '',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_order_logs`
-- -----------------------------
INSERT INTO `bao_community_order_logs` VALUES ('1', '1', '148', '140', '4', '1458006800', '17.53.27.1');
INSERT INTO `bao_community_order_logs` VALUES ('2', '1', '148', '280', '3', '1458006887', '17.53.27.1');
INSERT INTO `bao_community_order_logs` VALUES ('3', '1', '148', '0', '2', '1458006926', '17.53.27.1');
INSERT INTO `bao_community_order_logs` VALUES ('4', '1', '148', '1210', '1', '1458051668', '222.129.36.105');
INSERT INTO `bao_community_order_logs` VALUES ('5', '1', '231', '0', '2', '1458720977', '17.53.28.68');

-- -----------------------------
-- Table structure for `bao_community_order_products`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_order_products`;
CREATE TABLE `bao_community_order_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0' COMMENT '1水费  2电费 3燃气费 4停车费 5物业费',
  `order_id` int(10) DEFAULT '0',
  `money` int(10) DEFAULT '0',
  `bg_date` char(10) DEFAULT NULL,
  `end_date` char(10) DEFAULT NULL,
  `is_pay` tinyint(1) DEFAULT '0' COMMENT '0未缴 1已缴',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_order_products`
-- -----------------------------
INSERT INTO `bao_community_order_products` VALUES ('1', '1', '1', '2', '1210', '2016-03-01', '2016-03-31', '1');
INSERT INTO `bao_community_order_products` VALUES ('2', '1', '2', '2', '200', '2016-03-01', '2016-03-31', '1');
INSERT INTO `bao_community_order_products` VALUES ('3', '1', '3', '2', '280', '2016-03-01', '2016-03-31', '1');
INSERT INTO `bao_community_order_products` VALUES ('4', '1', '4', '2', '140', '2016-03-01', '2016-03-31', '1');
INSERT INTO `bao_community_order_products` VALUES ('5', '1', '5', '2', '0', '', '', '0');
INSERT INTO `bao_community_order_products` VALUES ('6', '1', '1', '3', '1200', '2016-03-23', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('7', '1', '2', '3', '1100', '2016-03-23', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('8', '1', '3', '3', '2300', '2016-03-23', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('9', '1', '4', '3', '1400', '2016-03-23', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('10', '1', '5', '3', '1400', '2016-03-23', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('11', '1', '1', '4', '1300', '2016-03-01', '2016-03-31', '1');
INSERT INTO `bao_community_order_products` VALUES ('12', '1', '2', '4', '1100', '2016-03-01', '2016-03-31', '1');
INSERT INTO `bao_community_order_products` VALUES ('13', '1', '3', '4', '13000', '2016-03-01', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('14', '1', '4', '4', '1100', '2016-03-01', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('15', '1', '5', '4', '800', '2016-03-01', '2016-03-31', '0');
INSERT INTO `bao_community_order_products` VALUES ('16', '1', '1', '5', '0', '水费开始时间', '水费结束时间', '0');
INSERT INTO `bao_community_order_products` VALUES ('17', '1', '2', '5', '0', '电费开始时间', '电费结束时间', '0');
INSERT INTO `bao_community_order_products` VALUES ('18', '1', '3', '5', '0', '燃气费开始时间', '燃气费结束时间', '0');
INSERT INTO `bao_community_order_products` VALUES ('19', '1', '4', '5', '10022200', '停车费开始时间', '停车费结束时间', '0');
INSERT INTO `bao_community_order_products` VALUES ('20', '1', '5', '5', '0', '物业费开始时间', '物业费结束时间', '0');

-- -----------------------------
-- Table structure for `bao_community_owner`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_owner`;
CREATE TABLE `bao_community_owner` (
  `owner_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `name` varchar(32) DEFAULT '' COMMENT '称呼',
  `number` int(10) DEFAULT '0' COMMENT '户号',
  `location` varchar(64) DEFAULT '' COMMENT '具体地址',
  `audit` tinyint(1) DEFAULT '0',
  `create_time` int(10) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT '',
  PRIMARY KEY (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_owner`
-- -----------------------------
INSERT INTO `bao_community_owner` VALUES ('7', '1', '227', '张先生', '0', '慧眼神仙子-', '0', '1458817354', '117.136.35.12');
INSERT INTO `bao_community_owner` VALUES ('3', '1', '231', '妖娆三', '1010', '一号楼601', '1', '1453103795', '60.222.163.225');
INSERT INTO `bao_community_owner` VALUES ('4', '2', '148', '关嚒', '0', '哪个快递', '0', '1453127532', '222.222.150.82');
INSERT INTO `bao_community_owner` VALUES ('6', '2', '227', '嗯嗯', '0', '嗯嗯嗯嗯', '0', '1458630070', '112.224.69.240');

-- -----------------------------
-- Table structure for `bao_community_posts`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_posts`;
CREATE TABLE `bao_community_posts` (
  `post_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `username` varchar(80) NOT NULL,
  `community_id` int(10) NOT NULL,
  `title` varchar(200) NOT NULL,
  `details` text NOT NULL,
  `views` int(11) DEFAULT '0',
  `audit` tinyint(11) DEFAULT '0',
  `gallery` varchar(500) NOT NULL,
  `view_num` int(10) NOT NULL DEFAULT '0',
  `reply_num` int(10) NOT NULL DEFAULT '0',
  `zan_num` int(10) NOT NULL DEFAULT '0',
  `create_time` int(10) NOT NULL,
  `create_ip` varchar(30) NOT NULL,
  `closed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_posts`
-- -----------------------------
INSERT INTO `bao_community_posts` VALUES ('1', '231', '13333333333', '1', '欧某你在吗', '<p>卖个包包</p>', '0', '1', '', '13', '0', '0', '1452681698', '60.222.163.166', '0');
INSERT INTO `bao_community_posts` VALUES ('2', '148', '测试号', '1', '发个帖子', '发个帖子', '0', '1', '2016/01/17/569b511f5407a.gif', '3', '0', '0', '1453019430', '222.222.150.82', '0');
INSERT INTO `bao_community_posts` VALUES ('3', '227', '1234567@qq.com', '2', '你好，再走一遍小区贴吧能用不？', '<p style=\"white-space: normal;\">各位新，由于baocms的bug多，最近本人全部重新走一遍，修复所有的BUG，尽请期待最终版上线吧！很是牛逼的版本来了哦！</p><p style=\"white-space: normal;\">附带一个美女图：</p><p style=\"white-space: normal;\">【后台没开启自动审核】</p><p><br/></p>', '0', '1', '2016/01/18/569d06875d54d.jpg', '150', '11', '50', '1453131400', '17.53.155.189', '0');
INSERT INTO `bao_community_posts` VALUES ('4', '227', '1234567@qq.com', '2', '测试下', '测试下', '0', '1', '', '8', '0', '0', '1453186680', '123.149.58.221', '0');
INSERT INTO `bao_community_posts` VALUES ('5', '148', '测试号', '2', '请输入标题', '小区论坛首页发帖时间显示（1970.1.1），日期显示错误', '0', '1', '', '6', '0', '0', '1454072402', '222.222.150.82', '0');
INSERT INTO `bao_community_posts` VALUES ('6', '148', '测试号', '2', '测试下', '还是测试下！', '0', '0', '', '0', '0', '0', '1458468546', '17.53.28.68', '0');
INSERT INTO `bao_community_posts` VALUES ('7', '148', '测试号', '1', '手机测试', '你好', '0', '0', '', '0', '0', '0', '1458737962', '123.147.244.70', '0');
INSERT INTO `bao_community_posts` VALUES ('8', '148', '测试号', '1', '你刚才', '你好', '0', '0', '', '0', '0', '0', '1458738103', '123.147.244.70', '0');
INSERT INTO `bao_community_posts` VALUES ('9', '148', '测试号', '1', '你好', '你好', '0', '0', '', '0', '0', '0', '1458738262', '123.147.244.70', '0');
INSERT INTO `bao_community_posts` VALUES ('10', '148', '测试号', '1', '你好', '你很好', '0', '0', '', '0', '0', '0', '1458738620', '123.147.244.70', '0');
INSERT INTO `bao_community_posts` VALUES ('11', '148', '测试号', '1', '1', '22', '0', '0', '2016/03/23/thumb_56f2961c22cad.jpg', '0', '0', '0', '1458738724', '17.53.28.68', '0');
INSERT INTO `bao_community_posts` VALUES ('12', '148', '测试号', '1', '11155', '图我哦哦哦', '0', '0', '2016/03/23/thumb_56f29647e4a4b.jpg', '0', '0', '0', '1458738767', '123.147.244.70', '0');
INSERT INTO `bao_community_posts` VALUES ('13', '148', '测试号', '1', '11155', '图我哦哦哦', '0', '0', '2016/03/23/thumb_56f29647e4a4b.jpg', '0', '0', '0', '1458738768', '123.147.244.70', '0');

-- -----------------------------
-- Table structure for `bao_community_replys`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_replys`;
CREATE TABLE `bao_community_replys` (
  `reply_id` int(10) NOT NULL AUTO_INCREMENT,
  `community_id` int(10) NOT NULL,
  `post_id` int(10) NOT NULL DEFAULT '0',
  `parent_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `details` text NOT NULL,
  `gallery` varchar(500) NOT NULL,
  `create_time` int(10) NOT NULL,
  `create_ip` varchar(20) NOT NULL,
  `audit` int(11) DEFAULT '0',
  PRIMARY KEY (`reply_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_replys`
-- -----------------------------
INSERT INTO `bao_community_replys` VALUES ('1', '2', '3', '0', '227', '<p>回帖试试？</p>', '', '1453131724', '17.53.155.189', '1');
INSERT INTO `bao_community_replys` VALUES ('2', '0', '3', '0', '148', '你号，我回复一个事实？', '', '1453133982', '17.53.155.189', '1');
INSERT INTO `bao_community_replys` VALUES ('3', '0', '3', '0', '148', '牛逼了o', '', '1453159179', '222.222.150.82', '0');
INSERT INTO `bao_community_replys` VALUES ('4', '0', '3', '0', '227', '试试', '', '1453179345', '123.149.58.221', '0');
INSERT INTO `bao_community_replys` VALUES ('5', '0', '3', '0', '148', '试试 ', '', '1453179426', '123.149.58.221', '0');
INSERT INTO `bao_community_replys` VALUES ('6', '0', '3', '0', '227', '测试下', '', '1453186726', '123.149.58.221', '0');
INSERT INTO `bao_community_replys` VALUES ('7', '0', '3', '0', '227', '试试', '', '1453264235', '115.54.100.206', '0');
INSERT INTO `bao_community_replys` VALUES ('8', '2', '3', '0', '148', '<p>你好，回复下。</p>', '', '1456558442', '17.53.31.218', '0');
INSERT INTO `bao_community_replys` VALUES ('9', '0', '3', '0', '148', '不错', '', '1457942236', '114.245.34.63', '0');
INSERT INTO `bao_community_replys` VALUES ('10', '0', '3', '0', '227', '看见了', '', '1458129641', '116.1.120.46', '0');
INSERT INTO `bao_community_replys` VALUES ('11', '0', '3', '0', '227', '空间有', '', '1458129842', '116.1.120.46', '0');

-- -----------------------------
-- Table structure for `bao_community_users`
-- -----------------------------
DROP TABLE IF EXISTS `bao_community_users`;
CREATE TABLE `bao_community_users` (
  `join_id` int(10) NOT NULL AUTO_INCREMENT,
  `community_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`join_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_community_users`
-- -----------------------------
INSERT INTO `bao_community_users` VALUES ('1', '1', '231');
INSERT INTO `bao_community_users` VALUES ('2', '1', '205');
INSERT INTO `bao_community_users` VALUES ('26', '2', '228');
INSERT INTO `bao_community_users` VALUES ('24', '2', '148');
INSERT INTO `bao_community_users` VALUES ('12', '2', '227');
INSERT INTO `bao_community_users` VALUES ('18', '2', '236');
INSERT INTO `bao_community_users` VALUES ('22', '2', '252');
INSERT INTO `bao_community_users` VALUES ('23', '1', '257');
INSERT INTO `bao_community_users` VALUES ('27', '1', '148');
INSERT INTO `bao_community_users` VALUES ('28', '1', '228');

-- -----------------------------
-- Table structure for `bao_connect`
-- -----------------------------
DROP TABLE IF EXISTS `bao_connect`;
CREATE TABLE `bao_connect` (
  `connect_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('weibo','test','weixin','qq') DEFAULT 'qq' COMMENT 'test 作为调试的时候使用！以免不懂得用户误会小弟啊',
  `open_id` varchar(32) DEFAULT NULL,
  `token` varchar(512) DEFAULT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `headimgurl` varchar(500) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`connect_id`),
  UNIQUE KEY `type` (`type`,`open_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_connect`
-- -----------------------------
INSERT INTO `bao_connect` VALUES ('1', 'weixin', '212121', '212121', '21212121', '', '2121');

-- -----------------------------
-- Table structure for `bao_convenient_phone`
-- -----------------------------
DROP TABLE IF EXISTS `bao_convenient_phone`;
CREATE TABLE `bao_convenient_phone` (
  `phone_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `orderby` tinyint(4) DEFAULT NULL,
  `details` text NOT NULL,
  `audit` int(11) DEFAULT NULL,
  PRIMARY KEY (`phone_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_convenient_phone`
-- -----------------------------
INSERT INTO `bao_convenient_phone` VALUES ('1', '修闹钟', '13333333333', '2016-02-13', '10', '', '1');
INSERT INTO `bao_convenient_phone` VALUES ('2', '特殊服务5', '15933985009', '2016-12-12', '2', '2', '1');
INSERT INTO `bao_convenient_phone` VALUES ('15', '北二环', '13334679446', '2016-12-21', '0', '', '1');
INSERT INTO `bao_convenient_phone` VALUES ('16', '后台测试', '13356781234', '2016-03-31', '1', '', '');

-- -----------------------------
-- Table structure for `bao_convenient_phone_maps`
-- -----------------------------
DROP TABLE IF EXISTS `bao_convenient_phone_maps`;
CREATE TABLE `bao_convenient_phone_maps` (
  `phone_id` int(11) DEFAULT NULL,
  `community_id` smallint(6) DEFAULT NULL,
  `audit` int(2) NOT NULL DEFAULT '0',
  UNIQUE KEY `phone_id` (`phone_id`,`community_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_convenient_phone_maps`
-- -----------------------------
INSERT INTO `bao_convenient_phone_maps` VALUES ('3', '2', '1');
INSERT INTO `bao_convenient_phone_maps` VALUES ('6', '1', '0');
INSERT INTO `bao_convenient_phone_maps` VALUES ('15', '1', '1');

-- -----------------------------
-- Table structure for `bao_convenient_phone_villages`
-- -----------------------------
DROP TABLE IF EXISTS `bao_convenient_phone_villages`;
CREATE TABLE `bao_convenient_phone_villages` (
  `phone_id` int(11) DEFAULT NULL,
  `village_id` smallint(6) DEFAULT NULL,
  UNIQUE KEY `phone_id` (`phone_id`,`village_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_convenient_phone_villages`
-- -----------------------------
INSERT INTO `bao_convenient_phone_villages` VALUES ('1', '1');

-- -----------------------------
-- Table structure for `bao_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `bao_coupon`;
CREATE TABLE `bao_coupon` (
  `coupon_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL,
  `cate_id` smallint(6) DEFAULT NULL,
  `city_id` smallint(6) DEFAULT '0',
  `area_id` smallint(6) DEFAULT '0',
  `business_id` smallint(6) DEFAULT '0',
  `title` varchar(128) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `views` int(11) DEFAULT '0',
  `downloads` int(11) DEFAULT '0',
  `intro` varchar(1024) DEFAULT NULL,
  `audit` tinyint(1) DEFAULT '0',
  `num` int(11) DEFAULT '9999999',
  `limit_num` tinyint(3) DEFAULT '0' COMMENT '0代表不限制',
  `closed` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`coupon_id`),
  KEY `cate_id` (`cate_id`,`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_coupon`
-- -----------------------------
INSERT INTO `bao_coupon` VALUES ('1', '1', '42', '1', '4', '0', '致在足道', '2016/03/10/thumb_56e14abda6b13.jpg', '2019-03-21', '75', '42', '仅售78元，价值128元盐浴足疗套系！免费WiFi、停车位！节假日通用！免预约！24小时接待！\r\n', '1', '514', '127', '0', '1457605322', '17.53.27.1');
INSERT INTO `bao_coupon` VALUES ('2', '2', '45', '1', '1', '0', '菲斯特咖啡', '2016/03/20/thumb_56ee5c4d5e0d6.jpg', '2016-03-31', '7', '2', '222', '1', '10', '2', '0', '1458461779', '17.53.28.68');
INSERT INTO `bao_coupon` VALUES ('3', '2', '45', '1', '1', '0', '你好', '2016/03/20/thumb_56ee6f739db45.jpg', '2016-03-25', '0', '0', '你好！', '0', '12', '2', '0', '1458466678', '17.53.28.68');
INSERT INTO `bao_coupon` VALUES ('4', '2', '45', '1', '1', '0', '测试wap编辑2', '2016/03/20/thumb_56ee71935feab.jpg', '2016-03-25', '6', '0', '你好！', '1', '12', '22', '0', '1458466792', '17.53.28.68');
INSERT INTO `bao_coupon` VALUES ('5', '5', '47', '1', '1', '0', '优惠价', '2016/03/21/thumb_56eeddc78b0dd.jpg', '2016-03-23', '0', '0', '优惠价优惠价优惠价优惠价', '0', '2', '2', '1', '1458494945', '58.16.111.230');
INSERT INTO `bao_coupon` VALUES ('6', '9', '46', '1', '1', '0', '充十抵12', '2016/03/26/thumb_56f69f1286263.png', '2016-06-30', '0', '0', '过期无效', '0', '10', '2', '0', '1459003226', '221.136.17.190');

-- -----------------------------
-- Table structure for `bao_coupon_download`
-- -----------------------------
DROP TABLE IF EXISTS `bao_coupon_download`;
CREATE TABLE `bao_coupon_download` (
  `download_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `mobile` char(11) DEFAULT NULL,
  `code` char(8) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `is_used` tinyint(1) DEFAULT '0',
  `is_sms` tinyint(1) DEFAULT '0',
  `used_time` int(11) DEFAULT NULL,
  `used_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`download_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_coupon_download`
-- -----------------------------
INSERT INTO `bao_coupon_download` VALUES ('2', '1', '1', '148', '13355888889', '14819142', '1457742876', '116.1.120.128', '1', '1', '1458725619', '117.136.35.23');
INSERT INTO `bao_coupon_download` VALUES ('3', '1', '1', '148', '13355888889', '48667815', '1457742939', '116.1.120.128', '1', '0', '1458172715', '222.129.36.105');
INSERT INTO `bao_coupon_download` VALUES ('5', '1', '1', '148', '13355888889', '13531918', '1458349783', '60.11.231.206', '1', '0', '1458975196', '17.53.152.211');
INSERT INTO `bao_coupon_download` VALUES ('6', '2', '2', '227', '13355888889', '28741790', '1458461852', '17.53.28.68', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('7', '1', '1', '227', '13567891234', '91514453', '1458617015', '117.41.246.108', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('8', '1', '1', '148', '13355888889', '27658173', '1459011739', '14.215.36.203', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('9', '2', '2', '148', '13355888889', '92951766', '1459012746', '14.215.36.203', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('10', '1', '1', '148', '18089672345', '19373476', '1459076391', '17.53.152.211', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('11', '1', '1', '148', '18089672345', '09562844', '1459079232', '17.53.152.211', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('12', '1', '1', '148', '18089672345', '01776436', '1459080074', '17.53.152.211', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('13', '1', '1', '148', '18089672345', '92760303', '1459080323', '17.53.152.211', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('14', '1', '1', '148', '18089672345', '20413239', '1459080327', '17.53.152.211', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('15', '1', '1', '148', '18089672345', '61234930', '1459080853', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('16', '1', '1', '148', '18089672345', '16923116', '1459080878', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('17', '1', '1', '148', '18089672345', '94960185', '1459081228', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('18', '1', '1', '148', '18089672345', '86583317', '1459081260', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('19', '1', '1', '148', '18089672345', '79320815', '1459081339', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('20', '1', '1', '148', '18089672345', '39043538', '1459081341', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('21', '1', '1', '148', '18089672345', '94600133', '1459081359', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('22', '1', '1', '148', '18089672345', '46073238', '1459081361', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('23', '1', '1', '148', '18089672345', '62934690', '1459081363', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('24', '1', '1', '148', '18089672345', '10675415', '1459081369', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('25', '1', '1', '148', '18089672345', '68271936', '1459081411', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('26', '1', '1', '148', '18089672345', '66485393', '1459081413', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('27', '1', '1', '148', '18089672345', '53872599', '1459081468', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('28', '1', '1', '148', '18089672345', '93254668', '1459081503', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('29', '1', '1', '148', '18089672345', '90727160', '1459081524', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('30', '1', '1', '148', '18089672345', '44428273', '1459081526', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('31', '1', '1', '148', '18089672345', '39882755', '1459081528', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('32', '1', '1', '148', '18089672345', '34839016', '1459081531', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('33', '1', '1', '148', '18089672345', '74035830', '1459081559', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('34', '1', '1', '148', '18089672345', '91532006', '1459081890', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('35', '1', '1', '148', '18089672345', '28397650', '1459081899', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('36', '1', '1', '148', '18089672345', '04961786', '1459081909', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('37', '1', '1', '148', '18089672345', '65827920', '1459081928', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('38', '1', '1', '148', '18089672345', '01363198', '1459081947', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('39', '1', '1', '148', '18089672345', '31950021', '1459081970', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('40', '1', '1', '227', '13567891234', '45378135', '1459084729', '112.224.67.18', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('41', '1', '1', '148', '18089672345', '29821300', '1459133626', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('42', '1', '1', '148', '18089672345', '09475118', '1459134006', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('43', '1', '1', '148', '18089672345', '35184534', '1459135566', '17.53.160.175', '0', '0', '', '');
INSERT INTO `bao_coupon_download` VALUES ('44', '1', '1', '277', '15157584621', '19177943', '1459145506', '122.97.172.19', '0', '0', '', '');

-- -----------------------------
-- Table structure for `bao_dayu_tag`
-- -----------------------------
DROP TABLE IF EXISTS `bao_dayu_tag`;
CREATE TABLE `bao_dayu_tag` (
  `dayu_id` int(11) NOT NULL AUTO_INCREMENT,
  `dayu_local` varchar(24) DEFAULT NULL,
  `dayu_name` varchar(128) DEFAULT NULL,
  `dayu_tag` varchar(36) DEFAULT NULL,
  `dayu_note` varchar(256) DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`dayu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_dayu_tag`
-- -----------------------------
INSERT INTO `bao_dayu_tag` VALUES ('1', 'sms_rlsj', '认领商家', 'SMS_6785129', '你好，你认领的商家【${shop_name}】在通过审核了，请登录${sitename}查看！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('2', 'sms_yzm', '验证码', 'SMS_6720152', '尊敬的用户：您在${sitename}手机认证的验证码是${code}千万别告诉别人！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('4', 'sms_yydy', '预约电子优惠券', 'SMS_6740177', '尊敬的用户您好,您预约了${shop_name}的电子优惠券：${code},亲可以前往${shop_name}进行消费;商家地址:${shop_addr},电话${shop_tel};', '1');
INSERT INTO `bao_dayu_tag` VALUES ('5', 'sms_tgdx', '团购后发送短信', 'SMS_6750225', '尊敬的${nickname}您在${sitename}订购的${tuan}的电子券是${code}；千万别告诉其他人！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('6', 'sms_zhmm', '找回密码', 'SMS_6735150', '尊敬的用户：您好，您在${sitename}的密码被重置成${newpwd}您可以使用${newpwd}重新登录！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('7', 'sms_sctzsj', '商城通知商家短信', 'SMS_6695214', '您好，您在${sitename}有新的订单！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('8', 'sms_tgtzsj', '团购通知商家', 'SMS_6720153', '您好，您在${sitename}有新的订单！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('9', 'sms_dcdx', '订餐后发送短信给用户', 'SMS_6755182', '尊敬的${nickname}您在${shopname}点的外卖订单已经生成，请耐心等待美食的到来。', '1');
INSERT INTO `bao_dayu_tag` VALUES ('10', 'sms_xdd', '新订单提醒', 'SMS_6700154', '您好，您在${sitename}有新的订单！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('11', 'sms_yycd', '预约场地', 'SMS_6145804', '${name}预约了您的场地，请及时登录你的网站回复。', '1');
INSERT INTO `bao_dayu_tag` VALUES ('12', 'sms_jftz', '缴费成功通知用户', 'SMS_6735152', '您好，您在${sitename}的${billtype}缴费订单已处理。', '1');
INSERT INTO `bao_dayu_tag` VALUES ('13', 'sms_tktz', '缴费退款通知', 'SMS_6740178', '您好，您在${sitename}的{billtype}缴费订单已退款，处理说明：${memo}', '1');
INSERT INTO `bao_dayu_tag` VALUES ('14', 'sms_fstg', '发送团购劵到用户', 'SMS_6735153', '尊敬的${user}，您在${shop_name}预定的团购验证密码为：${code}，请及时消费哦~', '1');
INSERT INTO `bao_dayu_tag` VALUES ('15', 'sms_gwtxsj', '商家提醒', 'SMS_6760150', '你好，有顾客在你的店铺购买了商品，请及时处理。\r\n(顾客购物后的商家提醒)', '1');
INSERT INTO `bao_dayu_tag` VALUES ('16', 'sms_dytz', '下载电子优惠券用户通知', 'SMS_6740176', '尊敬的用户您好，您下载了商家${shop_name}的电子优惠券${coupon_title}，电子优惠券为${code}，你可以在${expire_date}之前使用该优惠券！', '1');
INSERT INTO `bao_dayu_tag` VALUES ('17', 'dy_dxcs', '短信测试', 'SMS_6745170', '尊敬的${customer}，欢迎您使用阿里大鱼短信服务，阿里大鱼将为您提供便捷的通信服务！', '1');

-- -----------------------------
-- Table structure for `bao_delivery`
-- -----------------------------
DROP TABLE IF EXISTS `bao_delivery`;
CREATE TABLE `bao_delivery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL DEFAULT '',
  `mobile` varchar(11) NOT NULL DEFAULT '',
  `add_time` int(10) unsigned NOT NULL,
  `delivery_type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_delivery`
-- -----------------------------
INSERT INTO `bao_delivery` VALUES ('1', '123456', 'e10adc3949ba59abbe56e057f20f883e', '一号配送员', '13356781234', '1452760833', '1');
INSERT INTO `bao_delivery` VALUES ('2', '1234567', 'fcea920f7412b5da7be0cf42b8c93759', '测试', '13355666666', '1458623480', '0');

-- -----------------------------
-- Table structure for `bao_delivery_order`
-- -----------------------------
DROP TABLE IF EXISTS `bao_delivery_order`;
CREATE TABLE `bao_delivery_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL COMMENT '0是商城，1是外卖，2是快件',
  `type_order_id` int(10) unsigned NOT NULL COMMENT '关联的分类中的订单编号',
  `delivery_id` int(10) unsigned NOT NULL COMMENT '配送员ID',
  `shop_id` int(10) unsigned NOT NULL,
  `city_id` int(10) NOT NULL,
  `lat` varchar(15) DEFAULT NULL,
  `lng` varchar(15) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `shop_name` varchar(64) NOT NULL DEFAULT '',
  `shop_addr` varchar(64) NOT NULL DEFAULT '',
  `shop_mobile` varchar(64) DEFAULT '',
  `user_name` varchar(64) NOT NULL DEFAULT '',
  `user_addr` varchar(64) NOT NULL DEFAULT '',
  `user_mobile` varchar(11) DEFAULT '',
  `create_time` int(10) unsigned NOT NULL,
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '接单时间',
  `end_time` int(10) DEFAULT '0' COMMENT '完成时间 ',
  `status` tinyint(1) unsigned NOT NULL COMMENT '0是货到付款，1是已付款，2是配送中，8是已完成。',
  `closed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_delivery_order`
-- -----------------------------
INSERT INTO `bao_delivery_order` VALUES ('52', '0', '14', '1', '9', '1', '29.539711', '108.777649', '270', '重庆鸡公煲', '21号', '18755514777', '188@qq.com', '3号', '', '1458888040', '1458888272', '0', '2', '0');
INSERT INTO `bao_delivery_order` VALUES ('53', '1', '81', '1', '9', '0', '', '', '270', '重庆鸡公煲', '21号', '18755514777', '188@qq.com', '3号', '', '1458891901', '1459254905', '0', '2', '0');
INSERT INTO `bao_delivery_order` VALUES ('51', '0', '1', '1', '5', '1', '29.525507', '108.453469', '148', '九锅一堂', '测试多城市功能！', '13355678765', '测试号', '2222222222', '13355888889', '1458812588', '1458812958', '0', '8', '0');

-- -----------------------------
-- Table structure for `bao_ele`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele`;
CREATE TABLE `bao_ele` (
  `shop_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(64) DEFAULT NULL COMMENT '冗余方便查询',
  `city_id` smallint(5) unsigned DEFAULT NULL,
  `area_id` smallint(5) DEFAULT '0',
  `business_id` smallint(5) DEFAULT '0',
  `cate` varchar(64) DEFAULT NULL,
  `lng` varchar(15) DEFAULT NULL,
  `lat` varchar(15) DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT '0' COMMENT '1 代表营业中',
  `is_pay` tinyint(1) DEFAULT '0' COMMENT '1代表支持在线付款',
  `is_fan` tinyint(1) DEFAULT '0' COMMENT '1 代表返现',
  `fan_money` int(10) DEFAULT NULL,
  `is_new` tinyint(1) DEFAULT NULL,
  `full_money` int(10) DEFAULT '0' COMMENT '满多少MONEY 立刻减几元',
  `new_money` int(10) DEFAULT '0' COMMENT '减多少钱  比如说 满20减5元 那么  每增加10块钱 将额外减一元',
  `logistics` int(10) DEFAULT '0' COMMENT '0代表不收取配送费 填写其他的将代表收取',
  `since_money` int(10) DEFAULT NULL COMMENT '起送价',
  `sold_num` int(10) DEFAULT NULL,
  `month_num` int(10) DEFAULT NULL,
  `intro` varchar(1024) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100' COMMENT '数字越小排序越高',
  `distribution` tinyint(3) DEFAULT '30' COMMENT '分钟  配送时间',
  `audit` tinyint(3) unsigned DEFAULT '0' COMMENT '0审核中1成功入驻2未通过',
  `rate` int(11) DEFAULT '60' COMMENT '费率 每个商品的结算价格',
  PRIMARY KEY (`shop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele`
-- -----------------------------
INSERT INTO `bao_ele` VALUES ('3', '钮的店铺', '1', '2', '0', '1,2,3,4,5', '106.644822', '29.586687', '1', '1', '1', '300', '0', '10000', '200', '500', '5000', '0', '0', '&lt;p&gt;共和国符合规范&lt;/p&gt;', '100', '100', '1', '60');
INSERT INTO `bao_ele` VALUES ('1', '裕合园时尚宾馆', '1', '1', '11', '1,2,3,4,5,6', '108.777362', '29.539334', '1', '1', '0', '0', '0', '10000', '100', '0', '10', '822', '6', '我们是一家唯一做到30分钟全部送达的外卖餐馆。', '100', '30', '1', '0');
INSERT INTO `bao_ele` VALUES ('5', '九锅一堂', '1', '1', '0', '1,4', '108.453469', '29.525507', '0', '1', '1', '200', '1', '10000', '100', '200', '500', '0', '0', 'nihao !', '100', '60', '1', '60');
INSERT INTO `bao_ele` VALUES ('9', '重庆鸡公煲', '1', '1', '0', '1,2,3,4,5,6', '108.777649', '29.539711', '1', '1', '0', '0', '0', '0', '0', '0', '100', '1', '1', '&lt;p&gt;快&lt;/p&gt;', '100', '30', '1', '60');

-- -----------------------------
-- Table structure for `bao_ele_cate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele_cate`;
CREATE TABLE `bao_ele_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL,
  `cate_name` varchar(32) DEFAULT NULL,
  `num` int(11) DEFAULT '0',
  `closed` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`cate_id`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele_cate`
-- -----------------------------
INSERT INTO `bao_ele_cate` VALUES ('12', '3', '凉菜', '2', '0');
INSERT INTO `bao_ele_cate` VALUES ('13', '3', '热菜', '2', '0');
INSERT INTO `bao_ele_cate` VALUES ('14', '1', '面食', '2', '0');
INSERT INTO `bao_ele_cate` VALUES ('15', '1', '回锅肉', '1', '0');
INSERT INTO `bao_ele_cate` VALUES ('16', '9', '中餐', '5', '0');

-- -----------------------------
-- Table structure for `bao_ele_dianping`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele_dianping`;
CREATE TABLE `bao_ele_dianping` (
  `dianping_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `speed` tinyint(3) unsigned DEFAULT '0',
  `cost` int(11) DEFAULT NULL,
  `contents` varchar(1024) DEFAULT NULL,
  `reply` varchar(1024) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `closed` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `dianping_id` (`dianping_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele_dianping`
-- -----------------------------
INSERT INTO `bao_ele_dianping` VALUES ('1', '12', '148', '1', '4', '30', '12', '你好，订餐手机版评价！我后台修改的啊！', '你好商家回复！', '1453191152', '17.53.155.189', '2016-01-19', '0');
INSERT INTO `bao_ele_dianping` VALUES ('2', '11', '148', '1', '4', '30', '0', '你好', '', '1453191709', '17.53.155.189', '2016-01-19', '0');
INSERT INTO `bao_ele_dianping` VALUES ('3', '9', '148', '1', '3', '110', '0', '新的', '', '1453192007', '17.53.155.189', '2016-01-19', '0');
INSERT INTO `bao_ele_dianping` VALUES ('4', '8', '148', '1', '3', '30', '344', '你好是不是啊！你好，我后台测试下能不能修改？你好是不是啊！你好，我后台测试下能不能修改？', '回复4号外卖，后台回复下！', '1453192450', '17.53.155.189', '2016-01-19', '0');
INSERT INTO `bao_ele_dianping` VALUES ('5', '3', '148', '1', '5', '40', '50', '哈哈哈', '', '1453936717', '222.130.106.161', '2016-02-02', '0');
INSERT INTO `bao_ele_dianping` VALUES ('6', '35', '227', '1', '3', '30', '1', '1', '', '1456447422', '218.8.201.189', '2016-02-29', '0');

-- -----------------------------
-- Table structure for `bao_ele_dianping_pics`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele_dianping_pics`;
CREATE TABLE `bao_ele_dianping_pics` (
  `pic_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `pic` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`pic_id`),
  KEY `dianping_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele_dianping_pics`
-- -----------------------------
INSERT INTO `bao_ele_dianping_pics` VALUES ('1', '11', '2016/01/19/569df218a13a4.jpg');
INSERT INTO `bao_ele_dianping_pics` VALUES ('2', '9', '2016/01/19/569df344397bc.jpg');
INSERT INTO `bao_ele_dianping_pics` VALUES ('4', '8', '2016/01/19/569df5018901e.jpg');
INSERT INTO `bao_ele_dianping_pics` VALUES ('5', '8', '2016/01/19/thumb_569e2da1e9acf.jpg');
INSERT INTO `bao_ele_dianping_pics` VALUES ('6', '3', '2016/01/28/56a9504c2638a.jpg');

-- -----------------------------
-- Table structure for `bao_ele_order`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele_order`;
CREATE TABLE `bao_ele_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `addr_id` int(11) DEFAULT '0',
  `total_price` int(11) DEFAULT '0',
  `logistics` int(11) DEFAULT '0',
  `need_pay` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `new_money` int(11) DEFAULT '0',
  `fan_money` int(11) DEFAULT '0',
  `settlement_price` int(11) DEFAULT '0',
  `status` tinyint(3) DEFAULT '0' COMMENT '1等待处理  2代表已经确认  8代表配送完成',
  `is_pay` tinyint(1) DEFAULT '0' COMMENT '0是货到付款，1是在线支付',
  `create_time` int(11) DEFAULT '0',
  `create_ip` varchar(15) DEFAULT NULL,
  `audit_time` int(11) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  `month` int(11) DEFAULT '201501',
  `is_dianping` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele_order`
-- -----------------------------
INSERT INTO `bao_ele_order` VALUES ('86', '1', '227', '2', '10000', '0', '10000', '1', '0', '0', '10000', '1', '1', '1458914671', '42.48.125.157', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('85', '1', '227', '19', '120000', '0', '120000', '1', '0', '0', '120000', '8', '1', '1458914266', '42.48.125.157', '1458914401', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('84', '1', '227', '2', '130000', '0', '130000', '2', '0', '0', '130000', '1', '1', '1458900020', '17.53.28.68', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('83', '9', '249', '18', '3800', '0', '3800', '3', '0', '0', '3572', '1', '0', '1458898634', '117.169.6.78', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('82', '9', '227', '0', '2800', '0', '2800', '1', '0', '0', '2632', '0', '0', '1458897616', '1.196.47.185', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('81', '9', '270', '17', '3800', '0', '3800', '3', '0', '0', '3572', '2', '1', '1458891888', '218.87.242.129', '1458892013', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('80', '1', '249', '0', '10000', '0', '10000', '1', '0', '0', '10000', '0', '0', '1458833574', '117.169.6.78', '0', '1', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('79', '1', '148', '5', '130000', '0', '130000', '2', '0', '0', '130000', '8', '1', '1458811285', '17.53.28.68', '1458811306', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('78', '1', '148', '5', '80000', '0', '80000', '8', '0', '0', '80000', '8', '1', '1458811103', '17.53.28.68', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('77', '1', '148', '5', '10000', '0', '10000', '1', '0', '0', '10000', '8', '1', '1458810131', '17.53.28.68', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('87', '1', '148', '0', '130000', '0', '130000', '2', '0', '0', '130000', '0', '0', '1459042578', '17.53.152.211', '0', '0', '201603', '0');
INSERT INTO `bao_ele_order` VALUES ('88', '1', '148', '5', '1680000', '0', '1680000', '14', '0', '0', '1680000', '0', '0', '1459045109', '39.77.26.129', '0', '0', '201603', '0');

-- -----------------------------
-- Table structure for `bao_ele_order_product`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele_order_product`;
CREATE TABLE `bao_ele_order_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `num` int(11) DEFAULT '0',
  `total_price` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele_order_product`
-- -----------------------------
INSERT INTO `bao_ele_order_product` VALUES ('1', '1', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('2', '2', '14', '8', '14400', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('3', '3', '14', '9', '16200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('4', '4', '14', '9', '16200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('5', '5', '14', '9', '16200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('6', '6', '14', '9', '16200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('7', '7', '14', '10', '18000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('8', '8', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('9', '9', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('10', '10', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('11', '11', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('12', '12', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('13', '13', '14', '5', '9000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('14', '14', '14', '5', '9000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('15', '15', '14', '5', '9000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('16', '16', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('17', '17', '14', '5', '9000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('18', '18', '14', '5', '9000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('19', '19', '14', '6', '10800', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('20', '20', '14', '7', '12600', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('21', '21', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('22', '22', '14', '5', '9000', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('23', '23', '14', '6', '10800', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('24', '24', '14', '6', '10800', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('25', '25', '14', '4', '7200', '201601');
INSERT INTO `bao_ele_order_product` VALUES ('26', '26', '14', '5', '9000', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('27', '27', '14', '4', '7200', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('28', '28', '14', '6', '10800', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('29', '29', '14', '5', '9000', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('30', '30', '14', '4', '7200', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('31', '31', '14', '4', '7200', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('32', '32', '14', '4', '7200', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('33', '33', '14', '4', '7200', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('34', '34', '14', '4', '7200', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('35', '35', '14', '5', '9000', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('36', '36', '14', '1', '10', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('37', '37', '14', '1', '10', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('38', '38', '14', '1', '10', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('39', '39', '14', '1', '10', '201602');
INSERT INTO `bao_ele_order_product` VALUES ('40', '40', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('41', '41', '14', '2', '20', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('42', '42', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('43', '43', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('44', '44', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('45', '45', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('46', '46', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('47', '47', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('48', '48', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('49', '49', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('50', '50', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('51', '51', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('52', '52', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('53', '53', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('54', '54', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('55', '55', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('56', '56', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('57', '57', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('58', '58', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('59', '59', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('60', '60', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('61', '61', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('62', '62', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('63', '63', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('64', '64', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('65', '65', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('66', '66', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('67', '67', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('68', '68', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('69', '69', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('70', '70', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('71', '70', '15', '2', '240000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('72', '71', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('73', '72', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('74', '73', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('75', '74', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('76', '75', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('77', '76', '14', '1', '10', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('78', '77', '14', '1', '10000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('79', '78', '14', '8', '80000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('80', '79', '14', '1', '10000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('81', '79', '15', '1', '120000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('82', '80', '14', '1', '10000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('83', '81', '20', '1', '500', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('84', '81', '19', '1', '500', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('85', '81', '18', '1', '2800', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('86', '82', '18', '1', '2800', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('87', '83', '18', '1', '2800', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('88', '83', '19', '1', '500', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('89', '83', '20', '1', '500', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('90', '84', '14', '1', '10000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('91', '84', '15', '1', '120000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('92', '85', '15', '1', '120000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('93', '86', '14', '1', '10000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('94', '87', '14', '1', '10000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('95', '87', '15', '1', '120000', '201603');
INSERT INTO `bao_ele_order_product` VALUES ('96', '88', '15', '14', '1680000', '201603');

-- -----------------------------
-- Table structure for `bao_ele_product`
-- -----------------------------
DROP TABLE IF EXISTS `bao_ele_product`;
CREATE TABLE `bao_ele_product` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(32) DEFAULT NULL,
  `desc` varchar(255) NOT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `cate_id` int(11) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `settlement_price` int(11) unsigned DEFAULT NULL,
  `is_new` tinyint(1) DEFAULT '0',
  `is_hot` tinyint(1) DEFAULT '0',
  `is_tuijian` tinyint(1) DEFAULT '0',
  `sold_num` int(11) DEFAULT '0',
  `month_num` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `closed` tinyint(1) DEFAULT '0',
  `audit` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_ele_product`
-- -----------------------------
INSERT INTO `bao_ele_product` VALUES ('14', '面条', '简介面条的！', '1', '14', '2016/03/18/thumb_56eb5fa6d65ff.jpg', '10000', '10', '1', '1', '1', '79', '40', '1453121913', '17.53.155.189', '0', '1');
INSERT INTO `bao_ele_product` VALUES ('15', '回锅肉', '回锅肉的简介！', '1', '14', '2016/03/18/thumb_56eb5f98d7c07.jpg', '120000', '120000', '1', '1', '1', '4', '4', '1456845071', '17.53.154.172', '0', '1');
INSERT INTO `bao_ele_product` VALUES ('16', 'wap上传菜单', '你好，回锅肉222222', '1', '15', '2016/03/18/thumb_56eb60acb7b4a.jpg', '1260', '1260', '1', '1', '1', '0', '0', '1458266062', '17.53.28.68', '0', '0');
INSERT INTO `bao_ele_product` VALUES ('17', '大煲', '三到四人餐', '9', '16', '2016/03/25/thumb_56f4ea923ebb0.jpg', '3800', '3572', '1', '1', '1', '0', '0', '1458891420', '218.87.242.129', '0', '1');
INSERT INTO `bao_ele_product` VALUES ('18', '中煲', '中煲', '9', '16', '2016/03/25/thumb_56f4eab9657d5.jpg', '2800', '2632', '1', '1', '1', '1', '1', '1458891461', '218.87.242.129', '0', '1');
INSERT INTO `bao_ele_product` VALUES ('19', '白菜', '白菜', '9', '16', '2016/03/25/thumb_56f4eae04553b.jpg', '500', '470', '1', '1', '1', '1', '1', '1458891497', '218.87.242.129', '0', '1');
INSERT INTO `bao_ele_product` VALUES ('20', '金针磨', '白菜', '9', '16', '2016/03/25/thumb_56f4eafec218d.jpg', '500', '470', '1', '1', '1', '1', '1', '1458891500', '218.87.242.129', '0', '1');
INSERT INTO `bao_ele_product` VALUES ('21', '玉米', '绿色', '9', '16', '2016/03/26/thumb_56f69f8125d07.jpeg', '800', '752', '1', '1', '1', '0', '0', '1459003292', '221.136.17.190', '0', '1');

-- -----------------------------
-- Table structure for `bao_email`
-- -----------------------------
DROP TABLE IF EXISTS `bao_email`;
CREATE TABLE `bao_email` (
  `email_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email_key` varchar(32) DEFAULT NULL,
  `email_explain` varchar(1024) DEFAULT NULL,
  `email_tmpl` text,
  `is_open` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`email_id`),
  UNIQUE KEY `email_key` (`email_key`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_email`
-- -----------------------------
INSERT INTO `bao_email` VALUES ('1', 'email_rz', '邮件认证模版支持标签：\r\n{link}', '<p>尊敬的用户：</p><p>&nbsp; &nbsp; &nbsp;您复制以下链接即可完成邮件认证！</p><p>&nbsp; &nbsp; &nbsp;{link}</p><p>&nbsp; &nbsp; &nbsp;成为认证客户后可以申请更多的推广机会！</p><p>&nbsp; &nbsp; &nbsp;<strong>{sitename}</strong>祝您在本平台获得更多客户！客服联系电话：{tel}</p>', '1');
INSERT INTO `bao_email` VALUES ('2', 'email_newpwd', '找回密码：\r\n1、{newpwd}新密码', '<p>尊敬的用户：您好，您再{sitename}的密码被重置成{newpwd}您可以使用{newpwd}重新登录！【{sitename}】</p>', '1');
INSERT INTO `bao_email` VALUES ('3', 'email_yuyue', '{name}客户姓名\r\n{yuyue_date}时间\r\n{number}人数\r\n{content}内容\r\n{yuyue_time}预约几点\r\n{mobile}预约手机号', '<p>你好，尊敬的商家。</p><p>客户姓名：<span style=\"color: rgb(0, 0, 0); font-family: 微软雅黑; font-size: 12px; line-height: normal; white-space: normal; float: none;\">{name}</span></p><p>客户手机：{mobile}</p><p><span style=\"color: rgb(0, 0, 0); font-family: 微软雅黑; font-size: 12px; line-height: normal; white-space: normal; float: none;\">客户人数：<span style=\"color: rgb(0, 0, 0); font-family: 微软雅黑; font-size: 12px; line-height: normal; white-space: normal; float: none;\">{number}</span></span></p><p>预约时间：{yuyue_date}-{yuyue_time}</p><p>内容：{content}。</p><p>请及时登录<span style=\"color: rgb(0, 0, 0); font-family: 微软雅黑; line-height: normal; white-space: normal; float: none;\">{sitename}处理信息！</span></p>', '1');
INSERT INTO `bao_email` VALUES ('4', 'email_lifeservice_yuyue', '{name}：预约人姓名\r\n{date}：年，月，日\r\n{time}：预约时间\r\n{addr}：预约地址\r\n{tel}：预约电话\r\n{contents}：预约内容\r\n', '<p>尊敬的商家，{name}在<span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">{date}<span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">{time}预约了你的家政服务！</span></span></p><p><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">预约人电话：<span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">{tel}</span></span></span></p><p><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">预约人姓名：<span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">{name}</span></span></span></span></p><p><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">预约人地址：<span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">{addr}</span></span></span></span></span></p><p><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><br/></span></span></span></span></span></p><p><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\"><span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">预约内容：<span style=\"color: rgb(0, 0, 0); font-size: 12px; line-height: normal; white-space: normal; float: none;\">{contents}！</span></span></span></span></span></span></p><p>请登录<span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">{sitename}</span>查看！<br/></p>', '1');
INSERT INTO `bao_email` VALUES ('5', 'email_sj_lifeservice_yuyue', '{name}：预约人姓名\r\n{date}：年，月，日\r\n{time}：预约时间\r\n{addr}：预约地址\r\n{tel}：预约电话\r\n{contents}：预约内容\r\n', '<p style=\"white-space: normal;\">尊敬的网站管理员，{name}在<span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">{date}<span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">{time}预约了你的家政服务！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">预约人电话：<span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">{tel}</span></span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">预约人姓名：<span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">{name}</span></span></span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">预约人地址：<span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">{addr}</span></span></span></span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><br/></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\"><span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">预约内容：<span style=\"font-size: 12px; line-height: normal; color: rgb(0, 0, 0); float: none;\">{contents}！</span></span></span></span></span></span></p><p style=\"white-space: normal;\">请登录<span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\">{sitename}</span>查看！</p><p><br/></p>', '1');
INSERT INTO `bao_email` VALUES ('6', 'email_huodong_email', '{name}：预约人姓名\r\n{mobile}：预约人手机\r\n{num}：预约人数\r\n\r\n', '<p>你好，商家：{name}预约了您的活动了，人数{num}人，手机号：{mobile}，请尽快登录：<span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">{sitename}查看！</span></p>', '1');
INSERT INTO `bao_email` VALUES ('7', 'email_recognition', '{shop_name}商家名字\r\n{name}姓名\r\n{mobile}手机\r\n{content}理由\r\n{reply}回复', '<p>你好：{name}你在<span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">{sitename}认领的商家{shop_name}已通过审核：</span></p><p><span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\"><br/></span></p><p><span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">审核理由：{reply}，</span></p><p><span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\"><br/></span></p><p><span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">请登录：<span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">{sitename}查看！</span></span></p>', '1');
INSERT INTO `bao_email` VALUES ('8', 'pc_email_recognition', '用户申请认领邮件通知网站管理员！pc_email_recognition', '<p style=\"white-space: normal;\">你好，<span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">{sitename}</span>管理员：{name}你在<span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\">{sitename}认领的商家{shop_name}</span></p><p style=\"white-space: normal;\"><span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\"><br/></span></p><p style=\"white-space: normal;\"><span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\">申请理由：{content}！</span></p><p style=\"white-space: normal;\"><span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\">用户的手机号码：{mobile}。</span></p><p style=\"white-space: normal;\"><span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\"><br/></span></p><p style=\"white-space: normal;\"><span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\">请登录：<span style=\"line-height: normal; color: rgb(0, 0, 0); float: none;\">{sitename}查看！及时联系申请人！</span></span></p><p><br/></p>', '1');
INSERT INTO `bao_email` VALUES ('9', 'email_tz_delivery', '物流抢单后，通知购买人', '<p>你好：你的订单已被配送，请及时关注，或者登陆<span style=\"color: rgb(0, 0, 0); line-height: normal; white-space: normal; float: none;\">{sitename}查看,电话{tel}</span></p>', '1');
INSERT INTO `bao_email` VALUES ('10', 'email_tuisongemail', '邮件推送群发\r\n{title}\r\n{content}', '<p>你好，{title}，标题。</p><p><br/></p><p>内容：{content}</p><p><br/></p>', '1');

-- -----------------------------
-- Table structure for `bao_express`
-- -----------------------------
DROP TABLE IF EXISTS `bao_express`;
CREATE TABLE `bao_express` (
  `express_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT '0',
  `city_id` int(10) DEFAULT '0',
  `area_id` int(10) DEFAULT '0',
  `cid` int(10) DEFAULT '0',
  `business_id` int(10) DEFAULT '0',
  `title` varchar(64) DEFAULT NULL,
  `from_name` varchar(32) DEFAULT NULL,
  `from_addr` varchar(255) DEFAULT NULL,
  `from_mobile` varchar(11) DEFAULT NULL,
  `to_name` varchar(32) DEFAULT NULL,
  `to_addr` varchar(255) DEFAULT NULL,
  `to_mobile` varchar(11) DEFAULT NULL,
  `lat` varchar(15) DEFAULT NULL,
  `lng` varchar(15) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '0未处理，1已接单，2已完成，-1已拒收',
  `closed` tinyint(1) DEFAULT '0',
  `create_time` int(10) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `update_time` int(20) DEFAULT NULL,
  PRIMARY KEY (`express_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_express`
-- -----------------------------
INSERT INTO `bao_express` VALUES ('3', '148', '1', '0', '1', '0', 'PC测试增加快递', '李总', '重庆市合川区大河村3组', '13355555555', '何总', '北京市太和区新天下路', '18867872345', '30.030523', '107.236446', '2', '1', '1452858865', '17.53.155.230', '0');
INSERT INTO `bao_express` VALUES ('4', '148', '1', '0', '1', '0', 'wap测试', '李总', '寄件人地址', '13344444444', '收件人', '收件人地址', '13355555555', '16.038473', '103.734738', '2', '1', '1452873461', '17.53.155.230', '1452878878');
INSERT INTO `bao_express` VALUES ('5', '148', '1', '0', '1', '0', 'wap测试', '李总', '寄件人地址', '13344444444', '收件人', '收件人地址', '13355555555', '', '', '2', '0', '1452874448', '17.53.155.230', '1452876681');
INSERT INTO `bao_express` VALUES ('6', '148', '1', '0', '1', '0', 'wap测试', '李总', '寄件人地址', '13344444444', '收件人', '收件人地址', '13355555555', '', '', '2', '1', '1452874455', '17.53.155.230', '1452876700');
INSERT INTO `bao_express` VALUES ('7', '148', '1', '0', '1', '0', 'wap测试', '李总', '寄件人地址', '13344444444', '收件人', '收件人地址', '13355555555', '', '', '2', '0', '1452874460', '17.53.155.230', '1452908371');
INSERT INTO `bao_express` VALUES ('8', '148', '1', '0', '1', '0', 'wap测试2', '李总', '寄件人地址', '13344444444', '收件人', '收件人地址', '13355555555', '', '', '2', '0', '1452874465', '17.53.155.230', '1452908382');
INSERT INTO `bao_express` VALUES ('9', '148', '1', '0', '1', '0', '测试地址', '测试号 ', '你好地址', '13355888889', '1', '13355555555', '13355555555', '16.038473', '103.734738', '2', '0', '1452875956', '17.53.155.230', '1452922138');
INSERT INTO `bao_express` VALUES ('10', '148', '1', '0', '1', '0', '最新的', '测试号 ', '你好地址', '13355888889', '1', '13355555555', '13355555555', '16.020193', '103.734738', '2', '0', '1452876641', '17.53.155.230', '1452908525');
INSERT INTO `bao_express` VALUES ('12', '148', '1', '0', '0', '0', '最新的', '测试号 ', '你好地址', '13355888889', '1', '13355555555', '13355555555', '16.020193', '103.734738', '0', '1', '1452908332', '17.53.155.230', '0');
INSERT INTO `bao_express` VALUES ('11', '148', '1', '0', '1', '0', 'wap测试', '李总', '寄件人地址', '13344444444', '收件人', '收件人地址', '13355555555', '27.199738', '107.763866', '2', '0', '1452878728', '223.104.248.84', '1452878865');
INSERT INTO `bao_express` VALUES ('13', '234', '1', '1', '1', '0', '后台添加的快递众包', '李总', '呜呜呜呜', '13356781234', '何总', '4444444', '13356782313', '29.538957', '108.775422', '1', '0', '1452920028', '17.53.155.230', '1453116544');
INSERT INTO `bao_express` VALUES ('14', '148', '1', '0', '2', '0', '送原子弹给城管', '煎饼果子', '三轮车', '13838384848', '城管大队', '城管', '13474744848', '29.355467', '108.11294', '2', '0', '1458058781', '222.129.36.105', '1458633072');
INSERT INTO `bao_express` VALUES ('15', '227', '1', '0', '1', '0', '滨海', '1234567@qq.com ', '重庆市合川区', '13561124580', '陆地', '发送你还记得很美的的!', '18361124598', '29.353767', '108.109975', '2', '0', '1458093162', '114.236.196.225', '1458093408');

-- -----------------------------
-- Table structure for `bao_feedback`
-- -----------------------------
DROP TABLE IF EXISTS `bao_feedback`;
CREATE TABLE `bao_feedback` (
  `feed_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `community_id` int(11) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `details` text,
  `reply` text,
  `closed` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `reply_time` int(11) DEFAULT NULL,
  `reply_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`feed_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_feedback`
-- -----------------------------
INSERT INTO `bao_feedback` VALUES ('1', '231', '1', '电脑坏了', '来修一下', '你好，我是来回复的！', '0', '1452682226', '60.222.163.166', '1458711913', '17.53.28.68');
INSERT INTO `bao_feedback` VALUES ('2', '148', '2', '请输入标题', '以向青春家园反馈物业问题、提交意见等，还可以故障保修，如果时间紧急您可以拨打物业反馈物业问题、提交意见等，还可以故障保修，如果时间紧急您可以拨打物业', '', '0', '1457940820', '219.146.252.174', '0', '');
INSERT INTO `bao_feedback` VALUES ('3', '148', '1', '请输入标题', '以向青春家园反馈物业问题、提交意见等，还可以故障保修，如果时间紧急您可以拨打物业以向青春家园反馈物业问题、提交意见等，还可以故障保修，如果时间紧急您可以拨打物业以向青春家园反馈物业问题、提交意见等，还可以故障保修，如果时间紧急您可以拨打物业', '打物业电话吧', '0', '1457940845', '219.146.252.174', '1457940876', '219.146.252.174');

-- -----------------------------
-- Table structure for `bao_found`
-- -----------------------------
DROP TABLE IF EXISTS `bao_found`;
CREATE TABLE `bao_found` (
  `found_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL,
  `photo` varchar(64) DEFAULT NULL,
  `link_url` varchar(128) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `audit` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`found_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_found`
-- -----------------------------
INSERT INTO `bao_found` VALUES ('1', '发现生活第一季', '2014/11/19/thumb_546c3d32803b3.png', '/mobile/shop/index/cat/1.html', '1416379727', '127.0.0.1', '1');

-- -----------------------------
-- Table structure for `bao_goods`
-- -----------------------------
DROP TABLE IF EXISTS `bao_goods`;
CREATE TABLE `bao_goods` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL,
  `intro` varchar(128) DEFAULT NULL,
  `num` int(11) DEFAULT '0',
  `guige` varchar(64) DEFAULT NULL,
  `cate_id` int(11) DEFAULT NULL,
  `shopcate_id` int(11) DEFAULT NULL,
  `area_id` smallint(5) DEFAULT NULL,
  `business_id` smallint(5) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `city_id` varchar(64) DEFAULT NULL,
  `branch_id` varchar(64) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `wei_pic` varchar(256) DEFAULT NULL COMMENT '购物二维码',
  `price` int(11) DEFAULT NULL,
  `mall_price` int(11) DEFAULT NULL,
  `mobile_fan` int(11) NOT NULL,
  `min_price` int(11) NOT NULL,
  `settlement_price` int(11) DEFAULT '0',
  `sold_num` int(11) DEFAULT '0',
  `views` int(11) DEFAULT '0',
  `instructions` text,
  `details` text,
  `end_date` date DEFAULT NULL,
  `audit` tinyint(1) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  `is_mall` tinyint(3) DEFAULT '0',
  `is_vs1` int(2) DEFAULT '0',
  `is_vs2` int(2) DEFAULT '0',
  `is_vs3` int(2) DEFAULT '0',
  `is_vs4` int(2) DEFAULT '0',
  `is_vs5` int(2) DEFAULT '0',
  `is_vs6` int(2) DEFAULT '0',
  `commission` int(11) DEFAULT '0',
  `share` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `orderby` tinyint(4) DEFAULT '100',
  `use_integral` int(11) DEFAULT '0' COMMENT '可使用积分数',
  `profit_enable` int(1) DEFAULT '0',
  `profit_rate1` tinyint(3) DEFAULT '0',
  `profit_rate2` tinyint(3) DEFAULT '0',
  `profit_rate3` tinyint(3) DEFAULT '0',
  `profit_rank_id` tinyint(3) DEFAULT '0',
  PRIMARY KEY (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_goods`
-- -----------------------------
INSERT INTO `bao_goods` VALUES ('4', 'Apple/苹果 iPhone 6 4.7英寸 全网通手机', '送壳+钢化膜 分期0首付 移动联通电信 4G', '73', '台', '9', '9', '1', '11', '1', '1', '', '2016/01/16/thumb_569a643485454.jpg', '0', '16000', '8865', '288', '480000', '8667', '147', '6392', '<p>购买须知</p>', '<p><img src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/15/thumb_56e79925473eb.jpg\" _src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/15/thumb_56e79925473eb.jpg\"/></p>', '2019-01-24', '1', '0', '1', '1', '1', '1', '1', '1', '1', '0', '0', '1452958838', '17.53.155.230', '0', '600', '1', '2', '1', '1', '0');
INSERT INTO `bao_goods` VALUES ('5', '零生', '弱方法反反复复', '9000', '新', '2', '53', '1', '2', '2', '1', '', '2016/02/06/thumb_56b56b85f13d4.jpg', '0', '678900', '678000', '0', '0', '671220', '0', '0', '<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; bbbbbbbbbbbbbbbbbbbbbb<br/></p>', '<p>gggggggggggggggggggggggg<br/></p>', '2019-02-23', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '1454730139', '124.231.136.218', '100', '789', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('6', '价值308元的美程国际旅行社提供', '古古怪怪古古怪怪个个', '677', '新', '5', '53', '1', '2', '2', '1', '', '2016/02/06/thumb_56b56bb97271b.jpg', '0', '787800', '120000', '0', '0', '112800', '0', '0', '<p>gggggggggggggggggggg<br/></p>', '<p>gggggggggggggggg<br/></p>', '2018-03-10', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '1454730191', '124.231.136.221', '100', '567', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('7', '苹果', '山灵M2 Shanling发烧HiFi无损音乐mp3便携播放器', '8999', '呵呵呵呵呵呵呵呵呵', '2', '53', '1', '2', '2', '1', '', '2016/02/06/thumb_56b56beabfd0e.jpg', '0', '787800', '120000', '0', '0', '118800', '2', '28', '<p>gggggggggggggggggggg<br/></p>', '<p>gggggggggggggggggggggg<br/></p>', '2020-02-28', '1', '0', '1', '1', '1', '1', '0', '0', '0', '0', '0', '1454730244', '124.231.136.218', '100', '789', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('8', '苹果', '山灵M2 Shanling发烧HiFi无损音乐mp3便携播放器', '677', '呵呵呵呵呵呵呵呵呵', '2', '1', '1', '2', '4', '7', '', '2016/02/06/thumb_56b56c1b6cb5d.jpg', '0', '678900', '120000', '0', '0', '118800', '0', '0', '<p>gggggggggggggggggg<br/></p>', '<p>gggggggggggggggggggggg<br/></p>', '2019-03-09', '0', '0', '1', '1', '1', '1', '0', '0', '0', '0', '0', '1454730293', '124.231.136.218', '100', '789', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('9', 'g', 'gggggggggg', '9000', 'gggggggggggggggg', '5', '53', '1', '2', '2', '1', '', '2016/02/06/thumb_56b56c583eb4e.jpg', '0', '678900', '120000', '0', '0', '112800', '0', '0', '<p>vvvvvvvvvvvvvvvvvvvvvv<br/></p>', '<p>vvvvvvvvvvvvvvvvvvvvvvvv<br/></p>', '2019-03-02', '0', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1454730353', '124.231.136.218', '100', '100', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('10', 'dddddddddddddddddddddd', 'ssssssssssssssssss', '8999', '新', '3', '1', '1', '2', '2', '1', '', '2016/02/06/thumb_56b56c872ae01.jpg', '0', '678900', '120000', '0', '0', '112800', '1', '8', '<p>fffffffffffffffffffffffffffff<br/></p>', '<p>额生生世世生生世世三三<br/></p>', '2019-03-09', '1', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1454730411', '124.231.136.218', '100', '100', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('11', '很漂亮的文胸', '测试wap、下单', '-4', '件', '9', '0', '1', '2', '2', '1', '', '2016/03/12/thumb_56e3cf0e9ed23.jpg', '0', '10000', '8000', '122', '0', '7655', '259', '213', '<p>购买须知</p>', '<p>详情！</p>', '2019-03-13', '1', '0', '1', '1', '0', '0', '0', '0', '0', '100', '0', '1457770307', '17.53.27.1', '0', '100', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('12', '爱男女士全棉家居服套装', '爱男女士全棉家居服套装', '2', '件', '9', '0', '1', '3', '5', '1', '', '2016/03/12/thumb_56e3cfb0bc00f.jpg', '0', '10000', '9000', '399', '0', '8899', '137', '97', '<p>111</p>', '<p>22</p>', '2019-03-12', '1', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '1457770457', '17.53.27.1', '0', '300', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('13', 'wap测试', '副标题', '11', '件', '3', '53', '1', '11', '1', '1', '', '2016/03/20/thumb_56ee83a395fd3.jpg', '0', '10000', '9000', '8', '0', '8910', '10', '6', '<p>222</p>', '<p>222222222222222222222</p>', '2016-03-31', '1', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '1458471850', '17.53.28.68', '100', '200', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('14', '生日快乐', '生日玫瑰', '100', '束', '2', '55', '1', '2', '9', '1', '', '2016/03/25/thumb_56f4da13c8d13.jpg', '0', '10000', '9900', '0', '0', '9500', '1', '17', '<p><img src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/25/thumb_56f4da678fe28.jpg\" _src=\"http://baocms.fengmiyuanma.com/attachs/editor/2016/03/25/thumb_56f4da678fe28.jpg\"/></p><h1><strong><span style=\"COLOR: #7f7f7f; FONT-SIZE: 32px\">特别的爱给特别的你</span></strong></h1>', '<p>三小时送全国</p>', '2017-03-25', '1', '0', '1', '1', '1', '1', '1', '1', '1', '0', '0', '1458887365', '218.87.242.129', '100', '0', '0', '0', '0', '0', '0');
INSERT INTO `bao_goods` VALUES ('15', '香水鱼料包', '料包', '1000', '包', '2', '54', '1', '2', '9', '1', '', '2016/03/26/thumb_56f69bdf635d9.jpg', '0', '18000', '15000', '0', '0', '14850', '0', '1', '可以加盟', '加盟请致电', '2016-06-30', '1', '0', '1', '3', '0', '0', '0', '0', '0', '0', '0', '1459002471', '221.136.17.190', '100', '0', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `bao_goods_cate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_goods_cate`;
CREATE TABLE `bao_goods_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(32) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  `rate` int(11) DEFAULT '60' COMMENT '结算费率',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_goods_cate`
-- -----------------------------
INSERT INTO `bao_goods_cate` VALUES ('1', '休闲零食', '0', '1', '30');
INSERT INTO `bao_goods_cate` VALUES ('2', '糖果/巧克力', '1', '1', '10');
INSERT INTO `bao_goods_cate` VALUES ('3', '巧克力', '2', '1', '10');
INSERT INTO `bao_goods_cate` VALUES ('4', '手机', '0', '2', '60');
INSERT INTO `bao_goods_cate` VALUES ('5', '苹果手机', '4', '3', '60');
INSERT INTO `bao_goods_cate` VALUES ('9', '苹果手机', '5', '0', '0');

-- -----------------------------
-- Table structure for `bao_goods_dianping`
-- -----------------------------
DROP TABLE IF EXISTS `bao_goods_dianping`;
CREATE TABLE `bao_goods_dianping` (
  `order_id` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT '0',
  `score` int(11) DEFAULT NULL,
  `contents` varchar(1024) DEFAULT NULL,
  `reply` varchar(1024) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `closed` tinyint(2) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_goods_dianping`
-- -----------------------------
INSERT INTO `bao_goods_dianping` VALUES ('26', '4', '148', '1', '0', '4', '你好，测试机33', '你好333333333333333', '1453269518', '17.53.155.189', '2016-01-13', '0');
INSERT INTO `bao_goods_dianping` VALUES ('43', '4', '227', '1', '0', '4', '手机评价多图！', '', '1457773569', '17.53.27.1', '2016-03-15', '0');
INSERT INTO `bao_goods_dianping` VALUES ('130', '4', '148', '1', '0', '4', '手机不爱打字！', '222', '1457864883', '123.147.246.192', '2016-03-16', '0');
INSERT INTO `bao_goods_dianping` VALUES ('193', '4', '227', '1', '0', '4', '很不错哦！', '', '1458126815', '17.53.28.68', '2016-03-19', '0');
INSERT INTO `bao_goods_dianping` VALUES ('192', '4', '227', '1', '0', '1', '你好', '', '1458127087', '17.53.28.68', '2016-03-19', '0');
INSERT INTO `bao_goods_dianping` VALUES ('192', '4', '227', '1', '0', '1', '你好', '', '1458127263', '17.53.28.68', '2016-03-19', '0');
INSERT INTO `bao_goods_dianping` VALUES ('193', '4', '227', '1', '0', '3', '22', '', '1458127287', '17.53.28.68', '2016-03-19', '0');
INSERT INTO `bao_goods_dianping` VALUES ('191', '4', '227', '1', '0', '4', '22', '', '1458127307', '17.53.28.68', '2016-03-19', '0');
INSERT INTO `bao_goods_dianping` VALUES ('162', '4', '227', '1', '0', '3', '333', '', '1458127350', '17.53.28.68', '2016-03-19', '0');
INSERT INTO `bao_goods_dianping` VALUES ('29', '4', '227', '1', '0', '3', '很不错的商品！', '', '1458127385', '17.53.28.68', '2016-03-19', '0');

-- -----------------------------
-- Table structure for `bao_goods_dianping_pics`
-- -----------------------------
DROP TABLE IF EXISTS `bao_goods_dianping_pics`;
CREATE TABLE `bao_goods_dianping_pics` (
  `pic_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT NULL,
  `pic` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`pic_id`),
  KEY `dianping_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_goods_dianping_pics`
-- -----------------------------
INSERT INTO `bao_goods_dianping_pics` VALUES ('8', '0', '26', '2016/01/20/569f20ea13329.jpg');
INSERT INTO `bao_goods_dianping_pics` VALUES ('10', '0', '43', '2016/03/12/56e3db6d0ebf6.jpg');
INSERT INTO `bao_goods_dianping_pics` VALUES ('11', '0', '43', '2016/03/12/56e3db923484c.jpg');
INSERT INTO `bao_goods_dianping_pics` VALUES ('12', '0', '130', '2016/03/13/56e54076c47ca.png');
INSERT INTO `bao_goods_dianping_pics` VALUES ('13', '0', '130', '2016/03/13/56e5408825373.gif');
INSERT INTO `bao_goods_dianping_pics` VALUES ('14', '0', '130', '2016/03/13/56e540a1e55af.gif');

-- -----------------------------
-- Table structure for `bao_goods_photos`
-- -----------------------------
DROP TABLE IF EXISTS `bao_goods_photos`;
CREATE TABLE `bao_goods_photos` (
  `pic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT NULL,
  `photo` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`pic_id`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_goods_photos`
-- -----------------------------
INSERT INTO `bao_goods_photos` VALUES ('11', '1', '2016/01/14/56979b49877a6.jpg');
INSERT INTO `bao_goods_photos` VALUES ('12', '2', '2016/01/14/5697a2b56db59.jpg');
INSERT INTO `bao_goods_photos` VALUES ('25', '3', '2016/01/15/5697e610bacd4.jpg');
INSERT INTO `bao_goods_photos` VALUES ('82', '4', '2016/03/11/56e27d9177021.jpg');
INSERT INTO `bao_goods_photos` VALUES ('33', '5', '2016/02/06/56b56b879ab60.jpg');
INSERT INTO `bao_goods_photos` VALUES ('39', '6', '2016/02/06/56b56bbf54bcb.jpg');
INSERT INTO `bao_goods_photos` VALUES ('35', '7', '2016/02/06/56b56bf016765.png');
INSERT INTO `bao_goods_photos` VALUES ('36', '8', '2016/02/06/56b56c1ec7a15.jpg');
INSERT INTO `bao_goods_photos` VALUES ('37', '9', '2016/02/06/56b56c5c524ff.jpg');
INSERT INTO `bao_goods_photos` VALUES ('42', '10', '2016/02/06/56b56c8b26e3b.jpg');
INSERT INTO `bao_goods_photos` VALUES ('81', '4', '2016/01/16/569a64375ee4b.jpg');
INSERT INTO `bao_goods_photos` VALUES ('80', '4', '2016/02/27/56d1609eb9ffb.jpg');
INSERT INTO `bao_goods_photos` VALUES ('79', '4', '2016/02/27/56d160a0daae0.jpg');
INSERT INTO `bao_goods_photos` VALUES ('69', '11', '2016/03/12/thumb_56e3cf0ddda00.jpg');
INSERT INTO `bao_goods_photos` VALUES ('70', '12', '2016/03/12/thumb_56e3cfb23fbb4.jpg');
INSERT INTO `bao_goods_photos` VALUES ('88', '14', '2016/03/25/thumb_56f4da1f70a71.jpg');
INSERT INTO `bao_goods_photos` VALUES ('87', '14', '2016/03/25/thumb_56f4da28442ac.jpg');

-- -----------------------------
-- Table structure for `bao_goods_shopcate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_goods_shopcate`;
CREATE TABLE `bao_goods_shopcate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(32) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_goods_shopcate`
-- -----------------------------
INSERT INTO `bao_goods_shopcate` VALUES ('1', '上衣', '2', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('2', '下装', '10', '3');
INSERT INTO `bao_goods_shopcate` VALUES ('4', '服装', '1', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('6', '夏装', '95', '2');
INSERT INTO `bao_goods_shopcate` VALUES ('7', '电影院', '1', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('8', '自助餐', '1', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('9', '火锅', '1', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('13', '酒水', '1', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('15', '厨房用品', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('16', '厨房清洁', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('17', '厨房洗涤', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('18', '厨房杀毒', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('19', '厨房卫生', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('20', '洗浴用品', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('21', '锅碗瓢盆', '98', '100');
INSERT INTO `bao_goods_shopcate` VALUES ('22', '吃货', '95', '2');
INSERT INTO `bao_goods_shopcate` VALUES ('23', '上装', '95', '4');
INSERT INTO `bao_goods_shopcate` VALUES ('24', '鞋子', '95', '5');
INSERT INTO `bao_goods_shopcate` VALUES ('25', '水果', '95', '1');
INSERT INTO `bao_goods_shopcate` VALUES ('26', '家电', '95', '7');
INSERT INTO `bao_goods_shopcate` VALUES ('44', '测试产品分类', '130', '1');
INSERT INTO `bao_goods_shopcate` VALUES ('45', '手机2', '128', '1');
INSERT INTO `bao_goods_shopcate` VALUES ('46', '镜架', '134', '0');
INSERT INTO `bao_goods_shopcate` VALUES ('47', '镜片', '134', '0');
INSERT INTO `bao_goods_shopcate` VALUES ('48', '美瞳', '134', '0');
INSERT INTO `bao_goods_shopcate` VALUES ('49', '隐形眼镜', '134', '0');
INSERT INTO `bao_goods_shopcate` VALUES ('50', '测试类', '137', '1');
INSERT INTO `bao_goods_shopcate` VALUES ('51', '副食饮料', '139', '1');
INSERT INTO `bao_goods_shopcate` VALUES ('52', '居家生活', '139', '2');
INSERT INTO `bao_goods_shopcate` VALUES ('53', '妹子', '2', '0');
INSERT INTO `bao_goods_shopcate` VALUES ('54', '自营', '9', '0');
INSERT INTO `bao_goods_shopcate` VALUES ('55', '鲜花', '9', '1');

-- -----------------------------
-- Table structure for `bao_housekeeping_cate`
-- -----------------------------
DROP TABLE IF EXISTS `bao_housekeeping_cate`;
CREATE TABLE `bao_housekeeping_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(32) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `orderby` tinyint(3) NOT NULL DEFAULT '100',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_housekeeping_cate`
-- -----------------------------
INSERT INTO `bao_housekeeping_cate` VALUES ('1', '家政一级', '0', '1');
INSERT INTO `bao_housekeeping_cate` VALUES ('2', '家政', '0', '2');

-- -----------------------------
-- Table structure for `bao_housework`
-- -----------------------------
DROP TABLE IF EXISTS `bao_housework`;
CREATE TABLE `bao_housework` (
  `housework_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(3) DEFAULT '0',
  `id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `shop_id` int(10) DEFAULT NULL,
  `svctime` varchar(20) DEFAULT NULL,
  `addr` varchar(128) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `buy_num` tinyint(3) DEFAULT '0',
  `contents` varchar(1024) DEFAULT NULL,
  `is_real` tinyint(1) DEFAULT '0' COMMENT '1代表客服已经确认过是有效的',
  `num` tinyint(3) DEFAULT '0' COMMENT '未填数字就代表使用全局的',
  `gold` tinyint(3) DEFAULT '0' COMMENT '未填数字代表应用全局的设置',
  `city_id` smallint(5) DEFAULT '0',
  PRIMARY KEY (`housework_id`),
  KEY `svc_id` (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_housework`
-- -----------------------------
INSERT INTO `bao_housework` VALUES ('1', '1', '1', '148', '1', '2016-03-201', '你好，测试下预约功能！', '测试号', '13355888889', '1458487511', '17.53.28.68', '3', '你好，更多需求，我就是说需要你们的来服务好，至于什么服务，就看你多牛逼了！', '1', '3', '5', '0');
INSERT INTO `bao_housework` VALUES ('2', '1', '1', '227', '1', '选择服务时间', '填写服务地点', '1234567@qq.com', '13567891234', '1458616986', '117.41.246.108', '0', '填写其他要求', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `bao_housework_look`
-- -----------------------------
DROP TABLE IF EXISTS `bao_housework_look`;
CREATE TABLE `bao_housework_look` (
  `look_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `housework_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`look_id`),
  UNIQUE KEY `housework_id` (`housework_id`,`shop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_housework_look`
-- -----------------------------
INSERT INTO `bao_housework_look` VALUES ('2', '1', '1', '1458490796', '17.53.28.68');
INSERT INTO `bao_housework_look` VALUES ('3', '1', '2', '1458558371', '17.53.28.68');

-- -----------------------------
-- Table structure for `bao_housework_setting`
-- -----------------------------
DROP TABLE IF EXISTS `bao_housework_setting`;
CREATE TABLE `bao_housework_setting` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` int(10) DEFAULT '0',
  `shop_id` int(10) DEFAULT '0',
  `name` varchar(21) DEFAULT NULL,
  `price` int(11) DEFAULT '0',
  `unit` varchar(32) DEFAULT NULL,
  `gongju` varchar(64) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `thumb` text,
  `user` varchar(32) DEFAULT NULL,
  `tel` varchar(32) DEFAULT NULL,
  `biz_time` varchar(64) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `contents` text,
  `yuyue_num` int(11) DEFAULT '0',
  `views` int(11) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `bao_housework_setting`
-- -----------------------------
INSERT INTO `bao_housework_setting` VALUES ('1', '1', '1', '住家保姆', '10000', '1小时', '无', '2016/02/16/thumb_56c2df812f8bf.jpg', 'a:1:{i:0;s:28:\"2016/02/16/56c2df841e388.jpg\";}', '何娟', '13356782354', '9:00-12:00', '你好，建议亲周末预约。', '<p><img src=\"http://img.baidu.com/hi/jx2/j_0016.gif\" _src=\"http://img.baidu.com/hi/jx2/j_0016.gif\"/></p>', '3', '175', '0');

-- -----------------------------
-- Table structure for `bao_huodong`
-- -----------------------------
DROP TABLE IF EXISTS `bao_huodong`;
CREATE TABLE `bao_huodong` (
  `huodong_id` int(10) NOT NULL AUTO_INCREMENT,
  `cate_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `shop_id` int(10) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `limit_num` int(6) NOT NULL DEFAULT '0',
  `intro` varchar(128) DEFAULT NULL,
  `time` varchar(64) DEFAULT NULL,
  `audit` tinyint(1) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  `addr` varchar(1024) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT NULL,
  `traffic` tinyint(2) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `views` int(10) NOT NULL DEFAULT '0',
  `sign_num` int(11) DEFAULT '0',
  `ping_num` int(10) NOT NULL DEFAULT '0',
  `lat` varchar(15) DEFAULT '' COMMENT '纬度',
  `lng` varchar(15) DEFAULT '0' COMMENT '经度',
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`huodong_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `bao_huodong_dianping`
-- -----------------------------
DROP TABLE IF EXISTS `bao_huodong_dianping`;
CREATE TABLE `bao_huodong_dianping` (
  `dianping_id` int(11) NOT NULL,
  `huodong_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `contents` varchar(1024) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `create_ip` varchar(15) DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `closed` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`dianping_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

